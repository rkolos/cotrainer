args=(
  --credentials "$SRCROOT/Scripts/Localization/client_secret.json" \
  --platform "ios" \
  --spreadsheet "1nDw-j6-ih81Og8pQgrm-liFtqwZjMewaPtQ2IPXe_y4" \
  --formats-tab "goloc_formats" \
  --tab "mobile_localizations" \
  --key-column "key" \
  --resources "$SRCROOT/AIRepCount/Resources/Localization" \
  --default-localization "en" \
  --default-localization-file-path "$SRCROOT/AIRepCount/Resources/Localization/en.lproj/Localizable.strings" \
  --empty-localization-match "(^$|^[xX]$)"
)
if [ "${CONFIGURATION}" = "Release" ]; then
    args+=(--stop-on-missing)
fi

"$SRCROOT/Scripts/Localization/darwin_amd64" "${args[@]}"
