//
//  WatchSize.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 12.02.2024.
//

import SwiftUI

enum WatchSize {
  case mm41, mm45, mm49

  static var current: WatchSize {
    let bounds = WKInterfaceDevice.current().screenBounds

    if bounds.width >= 205 && bounds.height >= 251 {
      return .mm49
    } else if bounds.width >= 198 && bounds.height >= 242 {
      return .mm45
    } else if bounds.width >= 176 && bounds.height >= 215 {
      return .mm41
    } else {
      return .mm41
    }
  }
}
