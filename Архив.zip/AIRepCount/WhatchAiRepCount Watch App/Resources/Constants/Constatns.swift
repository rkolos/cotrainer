//
//  Constatns.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 17.02.2024.
//

import Foundation

struct Constants {
    struct AppStorageKey {
        static let countExercise = "countExercise"
        static let sessionStatus = "sessionStatus"
        static let vibration = "vibration"
        
        //Public
        static let selectedLanguage = "selectedLanguage"
    }
    
    struct Notifications {
        static let receiveMessageNotifications: NSNotification.Name = NSNotification.Name("receiveMessageNotifications")
        static let startWorkoutNotifications: NSNotification.Name = NSNotification.Name("startWorkoutNotifications")
    }
}
