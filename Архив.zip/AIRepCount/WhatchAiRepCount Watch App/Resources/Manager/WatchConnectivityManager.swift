//
//  WatchConnectivityManager.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 13.02.2024.
//

import Foundation
import WatchConnectivity
import CoreMotion
import SwiftUI

struct NotificationMessage: Identifiable, Equatable {
    let id = UUID()
    let time: String
    let accelerometer: String
    let magnetometer: String
    let gyro: String
}

enum SessionStatus: Int {
    case active
    case inactive
    case noActivated
}

enum TypeAcceleration: String {
    case gyro
    case accelerometer
    case magnetometer
}

let kInterfaceLanguage = "kInterfaceLanguage"
let kSelectedCount = "kSelectedCount"
let kCountExercise = "kCountExercise"
let kVibrationMode = "kVibrationMode"
let kStartWorkout = "kStartWorkout"

final class WatchConnectivityManager: NSObject, ObservableObject {
    static let shared = WatchConnectivityManager()
    
    @AppStorage(Constants.AppStorageKey.sessionStatus) var sessionStatus: SessionStatus?
    @AppStorage(Constants.AppStorageKey.countExercise) var selectedCount: Int = 12
    @AppStorage(Constants.AppStorageKey.vibration) var vibrationMode: Bool = false
    
    var data: [[String:String]] = []

    private override init() {
        super.init()
        
        if WCSession.isSupported() {
            WCSession.default.delegate = self
            WCSession.default.activate()
        }
    }
    
    
    
    func send(countExercise: Int? = nil, selectedCount: Int? = nil, interfaceLanguage: String? = nil, vibrationMode: Bool? = nil, startWorkout: Bool? = nil) {
        guard WCSession.default.activationState == .activated else {
            return
        }
#if os(iOS)
        guard WCSession.default.isWatchAppInstalled else {
            return
        }
#else
        guard WCSession.default.isCompanionAppInstalled else {
            return
        }
#endif
        
        if WCSession.default.isReachable == false {
            sendInfo(countExercise: countExercise, selectedCount: selectedCount, interfaceLanguage: interfaceLanguage, vibrationMode: vibrationMode, startWorkout: startWorkout)
        } else {
            
            var dict: [String : Any] = [:]
            
            if let countExercise = countExercise {
                dict[kCountExercise] = countExercise
            }
            
            if let selectedCount = selectedCount {
                dict[kSelectedCount] = selectedCount
            }
            
            if let interfaceLanguage = interfaceLanguage {
                dict[kInterfaceLanguage] = interfaceLanguage
            }
            
            if let vibrationMode = vibrationMode {
                dict[kVibrationMode] = vibrationMode
            }
            
            if let startWorkout = startWorkout {
                dict[kStartWorkout] = startWorkout
            }
            
            WCSession.default.sendMessage(dict, replyHandler: nil) { error in
                print("Cannot send message: \(String(describing: error))")
            }
        }
    }
    
    func sendFile(_ url: URL) {
        guard WCSession.default.activationState == .activated else {
            return
        }
#if os(iOS)
        guard WCSession.default.isWatchAppInstalled else {
            return
        }
#else
        guard WCSession.default.isCompanionAppInstalled else {
            return
        }
#endif
        
        WCSession.default.transferFile(url, metadata: nil)
    }
    
    func sendInfo(countExercise: Int? = nil, selectedCount: Int? = nil, interfaceLanguage: String? = nil, vibrationMode: Bool? = nil, startWorkout: Bool? = nil) {
        guard WCSession.default.activationState == .activated else {
            return
        }
#if os(iOS)
        guard WCSession.default.isWatchAppInstalled else {
            return
        }
#else
        guard WCSession.default.isCompanionAppInstalled else {
            return
        }
#endif
        
        do {
            var dict: [String : Any] = [:]
            
            if let countExercise = countExercise {
                dict[kCountExercise] = countExercise
            }
            
            if let selectedCount = selectedCount {
                dict[kSelectedCount] = selectedCount
            }
            
            if let interfaceLanguage = interfaceLanguage {
                dict[kInterfaceLanguage] = interfaceLanguage
            }
            
            if let vibrationMode = vibrationMode {
                dict[kVibrationMode] = vibrationMode
            }
            
            if let startWorkout = startWorkout {
                dict[kStartWorkout] = startWorkout
            }
            
            try WCSession.default.updateApplicationContext(dict)
        } catch {
            debugPrint("Error: \(error)")
        }
    }
}

extension WatchConnectivityManager: WCSessionDelegate {
    
    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String : Any]) {
        DispatchQueue.main.async {
#if os(iOS)
            //        AudioServicesPlaySystemSound(SystemSoundID(1103))
            if let countExercises = applicationContext[kCountExercise] as? Int {
                AudioManager.shared.playSound(count: countExercises)
            }
            
            if let selectedCount = applicationContext[kSelectedCount] as? Int {
                self.selectedCount = selectedCount
            }
            
            if let vibrationMode = applicationContext[kVibrationMode] as? Bool {
                self.vibrationMode = vibrationMode
            }
            
#else
            if let interfaceLanguage = applicationContext[kInterfaceLanguage] as? String {
                LocalizeR().localizeLanguage = interfaceLanguage
            }
            
            if let selectedCount = applicationContext[kSelectedCount] as? Int {
                self.selectedCount = selectedCount
            }
            
            if let vibrationMode = applicationContext[kVibrationMode] as? Bool {
                self.vibrationMode = vibrationMode
                
            }
            
            if let startWorkout = applicationContext[kStartWorkout] as? Bool {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    NotificationCenter.default.post(name: Constants.Notifications.startWorkoutNotifications, object: self, userInfo: nil)
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                NotificationCenter.default.post(name: Constants.Notifications.receiveMessageNotifications, object: self, userInfo: applicationContext)
            }
#endif
        }
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        DispatchQueue.main.async {
#if os(iOS)
            //        AudioServicesPlaySystemSound(SystemSoundID(1103))
            if let countExercises = message[kCountExercise] as? Int {
                AudioManager.shared.playSound(count: countExercises)
            }
            
            if let selectedCount = message[kSelectedCount] as? Int {
                self.selectedCount = selectedCount
            }
            
            if let vibrationMode = message[kVibrationMode] as? Bool {
                self.vibrationMode = vibrationMode
            }
            
#else
            if let interfaceLanguage = message[kInterfaceLanguage] as? String {
                LocalizeR().localizeLanguage = interfaceLanguage
            }
            
            if let selectedCount = message[kSelectedCount] as? Int {
                self.selectedCount = selectedCount
            }
            
            if let vibrationMode = message[kVibrationMode] as? Bool {
                self.vibrationMode = vibrationMode
            }
            
            if let startWorkout = message[kStartWorkout] as? Bool {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    NotificationCenter.default.post(name: Constants.Notifications.startWorkoutNotifications, object: self, userInfo: nil)
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                NotificationCenter.default.post(name: Constants.Notifications.receiveMessageNotifications, object: self, userInfo: message)
            }
#endif
        }
    }
    
    func session(_ session: WCSession,
                 activationDidCompleteWith activationState: WCSessionActivationState,
                 error: Error?) {
        
        DispatchQueue.main.async {
            
#if os(iOS)
            guard WCSession.default.isWatchAppInstalled, WCSession.isSupported() else {
                self.sessionStatus = .noActivated
                return
            }
#endif
            
            switch session.activationState {
            case .activated:
                self.sessionStatus = .active
            case .inactive:
                self.sessionStatus = .inactive
            case .notActivated:
                self.sessionStatus = .noActivated
            @unknown default:
                self.sessionStatus = .noActivated
            }
        }
    }
    
#if os(iOS)
    func sessionDidBecomeInactive(_ session: WCSession) {}
    func sessionDidDeactivate(_ session: WCSession) {
        session.activate()
    }
#endif
}
