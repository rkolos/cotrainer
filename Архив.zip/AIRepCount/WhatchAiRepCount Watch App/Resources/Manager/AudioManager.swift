//
//  AudioManager.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 22.02.2024.
//

import SwiftUI
import AVFoundation

class AudioManager {
    static let shared = AudioManager()
    private var audioPlayer: AVPlayer?
    
    @AppStorage(Constants.AppStorageKey.selectedLanguage) var storageAudioLanguage: LanguageAudio?
    @AppStorage(Constants.AppStorageKey.countExercise) var selectedCount: Int = 12
    @AppStorage(Constants.AppStorageKey.voiceSettingType) var settingSelected: VoiceSettingsType = .full
    @AppStorage(Constants.AppStorageKey.vibration) var vibrationMode: Bool = false
    
    func playSound(count: Int) {
        
        if count == selectedCount {
            if let deepLink = PreferencesManager.sharedManager.deepLinkValue, let url = URL(string: deepLink) {
                UIApplication.shared.open(url)
                PreferencesManager.sharedManager.deepLinkValue = nil
            }
        }
        
        guard !vibrationMode else {
            return
        }
        
        let fileName = detectFileName(count: count)
        
        if let storageAudioLanguage = storageAudioLanguage, let fileName = fileName {
            guard let file = getFileAsset(code: storageAudioLanguage, fileName: fileName) else { return }
            
            do {
                try AVAudioSession.sharedInstance()
                    .setCategory(.playback, options: .mixWithOthers)
                try AVAudioSession.sharedInstance()
                    .setActive(true)
            } catch {
                print(error)
            }
            
            audioPlayer = AVPlayer(playerItem: file)
            audioPlayer?.play()
            
            NotificationCenter.default
                .addObserver(self,
                             selector: #selector(playerDidFinishPlaying),
                             name: .AVPlayerItemDidPlayToEndTime,
                             object: audioPlayer?.currentItem
                )
        }
    }
    
    @objc func playerDidFinishPlaying(note: NSNotification) {
        DispatchQueue.global().async {
            do {
                try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
            } catch let error {
                print(error.localizedDescription)
            }
        }
    }
    
    private func getFileAsset(code: LanguageAudio, fileName: FileNameAudioEnum) -> AVPlayerItem? {
        let docsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        
        let destinationUrl = docsUrl?.appendingPathComponent("\(code.rawValue)/\(code.rawValue)-\(fileName.rawValue).mp3")
        
        if let destinationUrl = destinationUrl {
            if (FileManager().fileExists(atPath: destinationUrl.path)) {
                let avAssest = AVAsset(url: destinationUrl)
                return AVPlayerItem(asset: avAssest)
            } else {
                return nil
            }
        } else {
            return nil
        }
    }
    
    func playFileNameTwoTimes(fileName: FileNameAudioEnum, repeatCount: Int = 1) {
        if let storageAudioLanguage = storageAudioLanguage {
            guard let file = getFileAsset(code: storageAudioLanguage, fileName: fileName) else { return }
            
            do {
                try AVAudioSession.sharedInstance()
                    .setCategory(.playback, options: .mixWithOthers)
                try AVAudioSession.sharedInstance()
                    .setActive(true)
            } catch {
                print(error)
            }
            
            audioPlayer = AVPlayer(playerItem: file)
            audioPlayer?.play()
            
            NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: audioPlayer?.currentItem, queue: .main) { notification in
                if repeatCount == 2 {
                    self.playFileNameTwoTimes(fileName: fileName, repeatCount: 1)
                }
            }
            
            NotificationCenter.default
                .addObserver(self,
                             selector: #selector(playerDidFinishPlaying),
                             name: .AVPlayerItemDidPlayToEndTime,
                             object: audioPlayer?.currentItem
                )
        }
    }
    
    func playRandomDone() {
        
        let fileName = doneRandom()
        
        if let storageAudioLanguage = storageAudioLanguage {
            guard let file = getFileAsset(code: storageAudioLanguage, fileName: fileName) else { return }
            
            do {
                try AVAudioSession.sharedInstance()
                    .setCategory(.playback, options: .mixWithOthers)
                try AVAudioSession.sharedInstance()
                    .setActive(true)
            } catch {
                print(error)
            }
            
            audioPlayer = AVPlayer(playerItem: file)
            audioPlayer?.play()
            
            NotificationCenter.default
                .addObserver(self,
                             selector: #selector(playerDidFinishPlaying),
                             name: .AVPlayerItemDidPlayToEndTime,
                             object: audioPlayer?.currentItem
                )
        }
    }
    
    func stopPlayer() {
        NotificationCenter.default.removeObserver(self)
        audioPlayer?.pause()
        audioPlayer = nil
    }
    
    private func detectFileName(count: Int) -> FileNameAudioEnum? {
        if count == selectedCount {
            return doneRandom()
        }
        
        if settingSelected != .number {
            if count == (selectedCount - 1) {
                return .progress1
            }
            
            if selectedCount > 6 {
                if selectedCount / 2 == count {
                    return .progress50
                }
                
                if count == (selectedCount - 3) {
                    return .progress3
                }
                
                if count == (selectedCount - 2) {
                    return .progress2
                }
            }
        }
        
        if settingSelected == .key {
            return nil
        } else {
            return FileNameAudioEnum(rawValue: "\(count)")
        }
    }
    
    
    private func doneRandom() -> FileNameAudioEnum {
        let first = Int.random(in: 1...100)
        
        switch first {
        case 1...49:
            let done = Int.random(in: 1...5)
            return FileNameAudioEnum(rawValue: "done-\(done)") ?? .done1
        case 50...84:
            let done = Int.random(in: 6...9)
            return FileNameAudioEnum(rawValue: "done-\(done)") ?? .done1
            
        default:
            let done = Int.random(in: 10...15)
            return FileNameAudioEnum(rawValue: "done-\(done)") ?? .done1
        }
    }
    
}
