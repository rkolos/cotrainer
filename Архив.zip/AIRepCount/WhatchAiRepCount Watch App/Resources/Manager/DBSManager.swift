//
//  DBSManager.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 14.02.2024.
//

import SwiftUI
import simd
class DBSManager: ObservableObject {
    @Published var dbscanResult: (value: Int, count: Int) = (0,0)
    @Published var isCalculating: Bool = false    // Симафор состояния просчета.
    
    private let multiply = 20
    private let moves = 12
    private let epsilon = 4.3  // Threshold value for point simplification //TODO: вынести
    private let threshold = 9.5 //TODO: вынести
    private let EPS: Double = 30 //TODO: вынести
    private let MIN_SAMPLES = 2 //TODO: вынести
    private let ANGLE_THRESHOLD: Double = 24 // add to settings
    private let s_k: Double = 0.2
    private let max_k: Double = 0.25
    private let d: Double = 1.0
    
    @Published var currentElementCount: Int = 0
    private var mY = [Double]()
    private var mX = [Double]()
    private var mZ = [Double]()
    
    private var indexCut: [Int: Int] = [:]
    private var indexTemp: Int = 0

    private var isProcessingData = false
    private var initialBatchProcessed = false
    
    private var isStoped = false
    @Published var runned = false {
        didSet {
            if isStoped, runned == false {
                self.mY = []
                self.mX = []
                self.mZ = []
                self.dbscanResult = (0,0)
                self.isStoped = false
                self.isProcessingData = false
                self.initialBatchProcessed = false
                self.currentElementCount = 0
            }
        }
    }
    
    func clean() {
        self.mY = []
        self.mX = []
        self.mZ = []
        self.dbscanResult = (0,0)
        isStoped = true
        isProcessingData = false
        initialBatchProcessed = false
        currentElementCount = 0
    }
    
    func readData(model: NotificationMessage) {
        let magnetometer = model.magnetometer.components(separatedBy: ",")
        
        guard let mx = Double(magnetometer[safe: 0] ?? ""),
              let my = Double(magnetometer[safe: 1] ?? ""),
              let mz = Double(magnetometer[safe: 2] ?? "") else {
            return
        }
        
        mX.append(mx.rounded())
        mY.append(my.rounded())
        mZ.append(mz.rounded())
        
        if !isProcessingData && (initialBatchProcessed || mY.count >= multiply) {
            isProcessingData = true
            initialBatchProcessed = true // Указываем, что первый пакет данных обработан
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                self?.processData()
            }
        }
    }

    func processData() {
        
        DispatchQueue.main.async {
            self.runned = true
        }
        
        
        var points = [[Double]]()
        
        for index in 0..<self.mY.count - 1 {
            points.append([self.mX[index], self.mY[index], self.mZ[index]])
        }
        
        //  [[1.0, 2.0, 3.0], [2.0, 3.0, 4.0], [3.0, 4.0, 5.0]]  // Replace with your input data
        let simplifiedPoints = ramerDouglasPeucker(points, epsilon)
        
        let inputDF = DataFrame(data: simplifiedPoints)
        
        let filteredDF = filterPointsByDistance(inputDF, threshold: threshold)
        
        let pointsSimplified = filteredDF.data.compactMap({$0})
        
        var dataSimplified: [[Double]] = []
        
        if pointsSimplified.count >= 3 {
            for i in 1..<(pointsSimplified.count - 1) {
                let dataPoint = pointsSimplified[i - 1] + pointsSimplified[i] + pointsSimplified[i + 1]
                
                dataSimplified.append(dataPoint)
            }
        } else {
            isProcessingData = false
            return
        }

        
        let rowCount = dataSimplified.count
        var distMatrix = Array(repeating: Array(repeating: 0.0, count: rowCount), count: rowCount)
        
        for i in 0..<rowCount {
            for j in i+1..<rowCount {
                let distance = customDistance(point1: dataSimplified[i], point2: dataSimplified[j])
                distMatrix[i][j] = distance
                distMatrix[j][i] = distance // Симметричное заполнение
            }
        }
        
        let maxDistance = Double.greatestFiniteMagnitude
        let distMatrixWithMax = distMatrix.map { row in row.map { $0.isInfinite ? maxDistance : $0 } }
        
        //        var flatDistMatrix = distMatrixWithMax.flatMap { $0 }
        var dbResults = dbscan(distances: distMatrixWithMax, eps: EPS, minSamples: MIN_SAMPLES)
        dbResults.removeAll(where: { $0 == -1 })
        
        if let mostCommonCluster = mostFrequent(array: dbResults) {
            let filteredDbResults = dbResults.filter { $0 == mostCommonCluster.value }
            DispatchQueue.main.async { [weak self] in
                guard let `self` = self else { return }
                
                self.dbscanResult = (mostCommonCluster.value, filteredDbResults.count) // Обновляем dbscanResult
                
                if filteredDbResults.count > self.currentElementCount, !isStoped {
                    
                    self.indexCut[filteredDbResults.count] = points.count
                    self.currentElementCount = filteredDbResults.count
                    WatchConnectivityManager.shared.send(countExercise: filteredDbResults.count)
                    self.mX.removeAll()// Удаляю исходные массивы с данными
                    self.mY.removeAll()
                    self.mZ.removeAll()
                    simplifiedPoints.forEach { simplifiedPoints in // Заливаю в исходные данные - упращенные без промежуточных точек
                        if simplifiedPoints.count == 3 {
                            self.mX.append(simplifiedPoints[0])
                            self.mY.append(simplifiedPoints[1])
                            self.mZ.append(simplifiedPoints[2])
                        }
                    }
                }
                self.isProcessingData = false
                self.runned = false
            }
        } else {
            DispatchQueue.main.async { [weak self] in
                self?.isProcessingData = false
                self?.runned = false
            }
        }
    }
    
//    private func processDictionary() -> Int? {
//            // Проверяем, есть ли значение для ключа 2
//            guard let firstValue = indexCut[2] else { return nil }
//            
//            // Итерируем по ключам словаря, начиная с 4, так как изменения начинаются с этого ключа
//            for key in 4...6 {
//                if let value = indexCut[key] {
//                    indexCut[key - 2] = value - firstValue
//                }
//            }
//            
//            // Удаляем элементы с ключами 5 и 6
//            indexCut.removeValue(forKey: 5)
//            indexCut.removeValue(forKey: 6)
//            
//            // Возвращаем исходное значение элемента под номером 2
//            return firstValue
//        }

    
//    func test() {
//        guard let path = Bundle.main.path(forResource: "Abdominal111II.csv", ofType: nil),
//              let data = try? String(contentsOfFile: path, encoding: .utf8) else {
//            print("Failed to read CSV file at path: ")
//            return
//        }
//        
//        var lines = data.components(separatedBy: "\n")
//        let header = lines.removeFirst().components(separatedBy: ",")
//        var rows = [[String]]()
//        
//        for line in lines {
//            let values = line.components(separatedBy: ",")
//            rows.append(values)
//        }
//        var df_new = [[String: String]]()
//        for row in rows {
//            var rowData = [String: String]()
//            for (index, value) in row.enumerated() {
//                rowData[header[index]] = value
//            }
//            df_new.append(rowData)
//        }
//        
//        let mY = df_new.compactMap({Double($0["mY"] ?? "0") ?? 0})
//        let mX = df_new.compactMap({Double($0["mX"] ?? "0") ?? 0})
//        let mZ = df_new.compactMap({Double($0["mZ"] ?? "0") ?? 0})
//        
//        let normalizedMy = normalise(mY)
//        let normalizedMx = normalise(mX)
//        let normalizedMz = normalise(mZ)
//        
//        
//        
//        // Usage
//        var points = [[Double]]()
//        
//        for index in 0..<normalizedMx.count - 1 {
//            points.append([normalizedMx[index], normalizedMy[index], normalizedMz[index]])
//        }
//        
//        //  [[1.0, 2.0, 3.0], [2.0, 3.0, 4.0], [3.0, 4.0, 5.0]]  // Replace with your input data
//        let simplifiedPoints = ramerDouglasPeucker(points, epsilon)
//        
//        let inputDF = DataFrame(data: simplifiedPoints)
//        
//        let filteredDF = filterPointsByDistance(inputDF, threshold: threshold)
//        
//        let pointsSimplified = filteredDF.data.compactMap({$0})
//        
//        var dataSimplified: [[Double]] = []
//        
//        for i in 1..<(pointsSimplified.count - 1) {
//            let dataPoint = pointsSimplified[i - 1] + pointsSimplified[i] + pointsSimplified[i + 1]
//            
//            dataSimplified.append(dataPoint)
//        }
//        
//        let rowCount = dataSimplified.count
//        var distMatrix = Array(repeating: Array(repeating: 0.0, count: rowCount), count: rowCount)
//        
//        for i in 0..<rowCount {
//            for j in 0..<rowCount {
//                distMatrix[i][j] = customDistance(point1: dataSimplified[i], point2: dataSimplified[j])
//            }
//        }
//        // Handle infinite distances (if necessary)
//        let maxDistance = Double.greatestFiniteMagnitude
//        let distMatrixWithMax = distMatrix.map { row in row.map { $0.isInfinite ? maxDistance : $0 } }
//        
//        // Initialize the DBSCAN object
//        
//        
//        //        let flatDistMatrix = distMatrixWithMax.flatMap { $0 }
//        var db = dbscan(distances: distMatrixWithMax, eps: EPS, minSamples: MIN_SAMPLES)
//        
//        db.removeAll(where: {$0 == -1})
//        
//        if let result = mostFrequent(array: db) {
//            DispatchQueue.main.async {
//                self.dbscanResult = result
//                self.runned = false
//            }
//        }
//    }
    private func mostFrequent<T: Hashable>(array: [T]) -> (value: T, count: Int)? {
        
        let counts = array.reduce(into: [:]) { $0[$1, default: 0] += 1 }
        
        if let (value, count) = counts.max(by: { $0.1 < $1.1 }) {
            return (value, count)
        }
        
        // array was empty
        return nil
    }
}

// Define the `normalise` function
//extension DBSManager {
//    struct EasyMeanState {
//        var fit: Double = 0.0
//    }
//    
//    struct NormaliseState {
//        var medianBuffer: [Double] = [0.0, 0.0, 0.0]
//        var easyMeanState = EasyMeanState()
//    }
//    
//    private func normalise(_ data: [Double]) -> [Double] {
//        var output = [Double](repeating: 0.0, count: data.count)
//        var state = NormaliseState()
//        state.easyMeanState.fit = data[0]
//        
//        for (index, p) in data.enumerated() {
//            let medianResult = median(p, state: &state)
//            let easyMeanResult = easyMean(medianResult, state: &state.easyMeanState, s_k: s_k, max_k: max_k, d: d)
//            output[index] = easyMeanResult
//        }
//        
//        return output
//    }
//    
//    private func median(_ f: Double, state: inout NormaliseState) -> Double {
//        // Обновляем буфер для медианного фильтра
//        state.medianBuffer[0] = state.medianBuffer[1]
//        state.medianBuffer[1] = state.medianBuffer[2]
//        state.medianBuffer[2] = f
//        
//        // Вычисляем медиану без лишних сравнений
//        let sortedBuffer = state.medianBuffer.sorted()
//        return sortedBuffer[1]
//    }
//    
//    private func easyMean(_ f: Double, state: inout EasyMeanState, s_k: Double, max_k: Double, d: Double) -> Double {
//        let k = abs(f - state.fit) < d ? s_k : max_k
//        state.fit += (f - state.fit) * k
//        return state.fit
//    }
//}


//MARK: - ramerDouglas
extension DBSManager {
    private func ramerDouglasPeucker(_ points: [[Double]], _ epsilon: Double) -> [[Double]] {
        // Проверка, что есть достаточное количество точек для обработки
        guard points.count > 2 else { return points }
        
        var dmax = 0.0
        var index = 0
        let end = points.count - 1
        
        // Нахождение точки с максимальным расстоянием
        for i in 1..<end {
            let d = pointLineDistance(point: points[i], start: points[0], end: points[end])
            if d > dmax {
                index = i
                dmax = d
            }
        }
        
        // Если максимальное расстояние больше эпсилон, рекурсивно применяем алгоритм
        if dmax > epsilon {
            let recResults1 = ramerDouglasPeucker(Array(points[0...index]), epsilon)
            let recResults2 = ramerDouglasPeucker(Array(points[index...]), epsilon)
            // Объединение результатов
            return Array(recResults1.dropLast()) + recResults2
        } else {
            return [points[0], points[end]]
        }
    }
    
    private func pointLineDistance(point: [Double], start: [Double], end: [Double]) -> Double {
        guard point.count == 3, start.count == 3, end.count == 3 else {
            fatalError("All points must have 3 elements.")
        }
        
        let pointVec = simd_double3(point)
        let startVec = simd_double3(start)
        let endVec = simd_double3(end)
        
        if startVec == endVec {
            return simd_distance(pointVec, startVec)
        } else {
            let lineVec = endVec - startVec
            let pointLineVec = pointVec - startVec
            let cross = simd_cross(lineVec, pointLineVec)
            return simd_length(cross) / simd_length(lineVec)
        }
    }

    private func distance(_ a: [Double], _ b: [Double]) -> Double {
        guard a.count == 3, b.count == 3 else {
            fatalError("Vectors must have 3 elements.")
        }
        
        let aVec = simd_double3(a)
        let bVec = simd_double3(b)
        return simd_distance(aVec, bVec)
    }

    private func crossProduct(_ a: [Double], _ b: [Double]) -> [Double] {
        guard a.count == 3, b.count == 3 else {
            fatalError("Both vectors must have 3 elements for cross product.")
        }
        
        let aVec = simd_double3(a)
        let bVec = simd_double3(b)
        let crossVec = simd_cross(aVec, bVec)
        return [crossVec.x, crossVec.y, crossVec.z]
    }
    
    private func vectorNorm(_ vector: [Double]) -> Double {
        return sqrt(vector.reduce(0) { $0 + $1 * $1 })
    }
}


extension DBSManager {
    struct DataFrame {
        var data: [[Double]]
        
        init(data: [[Double]]) {
            self.data = data
        }
        
        func getRow(_ index: Int) -> [Double] {
            guard index >= 0 && index < data.count else {
                fatalError("Index out of bounds while accessing DataFrame row.")
            }
            return data[index]
        }
        
        func count() -> Int {
            return data.count
        }
    }
    
    private func filterPointsByDistance(_ df: DataFrame, threshold: Double) -> DataFrame {
        guard !df.data.isEmpty else { return DataFrame(data: []) }
        
        var newDF = DataFrame(data: [df.getRow(0)])
        
        for i in 1..<df.count() {
            let currentPoint = df.getRow(i)
            let lastPointInNewDF = newDF.getRow(newDF.count() - 1)
            
            // Использование SIMD оптимизированной функции расчета расстояния
            let distance = CalculateDistance(currentPoint, lastPointInNewDF)
            if distance >= threshold {
                newDF.data.append(currentPoint)
            }
        }
        
        return newDF
    }
    
    private func CalculateDistance(_ a: [Double], _ b: [Double]) -> Double {
        guard a.count == b.count else {
            fatalError("Vectors must have the same number of elements to calculate distance.")
        }

        // Преобразование входных векторов в SIMD формат
        let vecA = simd_double3(a[0], a[1], a[2])
        let vecB = simd_double3(b[0], b[1], b[2])

        // Вычисление евклидова расстояния с использованием SIMD
        return simd_distance(vecA, vecB)
    }
}


//MARK:- customDistance
extension DBSManager {
    private func customDistance(point1: [Double], point2: [Double]) -> Double {
        guard point1.count >= 6, point2.count >= 6 else {
            fatalError("Points must have at least 6 elements.")
        }
        
        
        
        let prevVector1 = vectorSubtract(Array(point1[0..<3]), Array(point1[3..<6]))
        let nextVector1 = vectorSubtract(Array(point1[6..<9]), Array(point1[3..<6]))
        
        let prevVector2 = vectorSubtract(Array(point2[0..<3]), Array(point2[3..<6]))
        let nextVector2 = vectorSubtract(Array(point2[6..<9]), Array(point2[3..<6]))
        
        let inOutAngle1 = computeAngleBetweenVectors(prevVector1, nextVector1)
        let inOutAngle2 = computeAngleBetweenVectors(prevVector2, nextVector2)
        
        if inOutAngle1 <= ANGLE_THRESHOLD && inOutAngle2 <= ANGLE_THRESHOLD {
            let prevAngle = computeAngleBetweenVectors(prevVector1, prevVector2)
            let nextAngle = computeAngleBetweenVectors(nextVector1, nextVector2)
            
            if prevAngle <= ANGLE_THRESHOLD && nextAngle <= ANGLE_THRESHOLD {
                return euclidean(Array(point1[3..<6]), Array(point2[3..<6]))
            }
        }
        return Double.greatestFiniteMagnitude
    }
    
    private func computeAngleBetweenVectors(_ v1: [Double], _ v2: [Double]) -> Double {
        guard v1.count == v2.count, v1.count >= 3 else {
            fatalError("Vectors must have the same non-zero number of elements and at least 3 elements.")
        }

        // Создание SIMD векторов из входных массивов
        let vector1 = simd_double3(v1[0], v1[1], v1[2])
        let vector2 = simd_double3(v2[0], v2[1], v2[2])

        // Вычисление скалярного произведения и норм векторов
        let dotProduct = simd_dot(vector1, vector2)
        let magnitude1 = simd_length(vector1)
        let magnitude2 = simd_length(vector2)

        // Вычисление косинуса угла между векторами
        let cosTheta = dotProduct / (magnitude1 * magnitude2)

        // Вычисление угла в радианах и его преобразование в градусы
        let angle = acos(min(max(cosTheta, -1.0), 1.0)) * 180.0 / .pi

        return angle
    }
    
    private func euclidean(_ vector1: [Double], _ vector2: [Double]) -> Double {
        guard vector1.count == vector2.count else {
            fatalError("Vectors must be the same length to calculate Euclidean distance.")
        }
        
        let squaredDifferences = zip(vector1, vector2).map { ($0 - $1) * ($0 - $1) }
        return sqrt(squaredDifferences.reduce(0, +))
    }
    
    private func vectorSubtract(_ a: [Double], _ b: [Double]) -> [Double] {
        guard a.count == b.count else {
            fatalError("Vectors must be the same length for subtraction.")
        }
        
        return zip(a, b).map(-)
    }
}


//MARK: - dbscan
extension DBSManager {
    private func dbscan(distances: [[Double]], eps: Double, minSamples: Int) -> [Int] {
        guard !distances.isEmpty else {
            print("Distances array must be non-empty.")
            return []
        }

        var clusterIndex = 0
        var visited = Set<Int>()
        var labels = [Int](repeating: -1, count: distances.count)
        var neighborsList = Array(repeating: [Int](), count: distances.count)

        // Предварительный поиск соседей для каждой точки
        for i in 0..<distances.count {
            neighborsList[i] = findNeighbors(pointIndex: i, distances: distances, eps: eps)
        }

        // Основной цикл по точкам
        for i in 0..<distances.count {
            if !visited.contains(i) {
                visited.insert(i)
                let neighbors = neighborsList[i]

                if neighbors.count < minSamples {
                    labels[i] = -1 // Noise
                } else {
                    clusterIndex += 1
                    expandCluster(pointIndex: i, neighbors: neighbors, clusterIndex: clusterIndex, neighborsList: &neighborsList, labels: &labels, visited: &visited, minSamples: minSamples)
                }
            }
        }

        return labels
    }

    private func expandCluster(pointIndex: Int, neighbors: [Int], clusterIndex: Int, neighborsList: inout [[Int]], labels: inout [Int], visited: inout Set<Int>, minSamples: Int) {
        labels[pointIndex] = clusterIndex

        var searchQueue = neighbors
        while !searchQueue.isEmpty {
            let currentPointIndex = searchQueue.removeFirst()
            if !visited.contains(currentPointIndex) {
                visited.insert(currentPointIndex)
                let currentNeighbors = neighborsList[currentPointIndex]
                if currentNeighbors.count >= minSamples {
                    searchQueue.append(contentsOf: currentNeighbors.filter { !visited.contains($0) })
                }
            }
            if labels[currentPointIndex] == -1 {
                labels[currentPointIndex] = clusterIndex
            }
        }
    }

    private func findNeighbors(pointIndex: Int, distances: [[Double]], eps: Double) -> [Int] {
        distances[pointIndex].enumerated().compactMap { $1 < eps ? $0 : nil }
    }
}

