//
//  HapticsEngine.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 13.02.2024.
//

import SwiftUI
import CoreMotion
import HealthKit

class HapticsEngine: NSObject, ObservableObject {
    @Published var isStart = false
    @Published var notificationMessage: NotificationMessage? = nil
    
    var healthStore = HKHealthStore()
    
    private var manager: CMMotionManager?
    private var sessionWK: WKExtendedRuntimeSession?
    
    private var session: HKWorkoutSession?
    private var builder: HKLiveWorkoutBuilder?
    
    private var isPlaying: Bool = false
    
    private func startSessionIfNeeded() {
        guard !isPlaying, sessionWK?.state != .running else { return }
        
        sessionWK = WKExtendedRuntimeSession()
        sessionWK?.delegate = self
        sessionWK?.start()
    }
    
    private func stopSession() {
        sessionWK?.invalidate()
    }
    
    private func startPlayingTicks() {
        startSessionIfNeeded()
        isStart.toggle()
    }
    
    //MARK: - Stop Engine
    
    func stop() {
        manager?.stopDeviceMotionUpdates()
        
        manager = nil
        
        stopSession()
        
        DispatchQueue.main.async {
            self.notificationMessage = nil
        }
        
        stopWorkout()
        
        isStart.toggle()
    }
    
    //MARK: - Start Engine
    func start() {
        manager = CMMotionManager()
        
        
        manager?.deviceMotionUpdateInterval = 0.05
        manager?.startDeviceMotionUpdates()
        
        self.manager?.startDeviceMotionUpdates(using: .xMagneticNorthZVertical, to: OperationQueue.current!, withHandler: { data, error in
            if let data = data {
                self.notificationMessage = NotificationMessage(time: Date().stringFromDate(), accelerometer: "\(data.userAcceleration.x),\(data.userAcceleration.y),\(data.userAcceleration.z)", magnetometer: "\(data.magneticField.field.x),\(data.magneticField.field.y),\(data.magneticField.field.z)", gyro: "\(data.rotationRate.x),\(data.rotationRate.y),\(data.rotationRate.z)")
                
            }
        })
        
        startPlayingTicks()
        startWorkout()
    }
}

//MARK: - Workouts
extension HapticsEngine {
    private func startWorkout() {
        let configuration = HKWorkoutConfiguration()
        configuration.activityType = .traditionalStrengthTraining
        configuration.locationType = .unknown
        
        do {
            session = try HKWorkoutSession(healthStore: healthStore, configuration: configuration)
            builder = session?.associatedWorkoutBuilder()
        } catch {
            // Handle error
        }
        
        //            delegate = WorkoutSessionDelegate()
        //            session?.delegate = delegate
        //            builder?.delegate = delegate
        
        builder?.dataSource = HKLiveWorkoutDataSource(healthStore: healthStore,
                                                      workoutConfiguration: configuration)
        
        // Start the workout session
        session?.startActivity(with: Date())
        builder?.beginCollection(withStart: Date()) { success, error in
            debugPrint("\(success) \(error?.localizedDescription ?? "")")
        }
    }
    
    private func stopWorkout() {
        session?.end()
        builder?.endCollection(withEnd: Date()) { success, error in
            // Handle success or error
        }
        
        builder?.finishWorkout { workout, error in
            // Handle completion
        }
    }
}

extension HapticsEngine: WKExtendedRuntimeSessionDelegate {
    func extendedRuntimeSession(_ extendedRuntimeSession: WKExtendedRuntimeSession, didInvalidateWith reason: WKExtendedRuntimeSessionInvalidationReason, error: Error?) {
        print("extendedRuntimeSession")
    }
    
    func extendedRuntimeSessionDidStart(_ extendedRuntimeSession: WKExtendedRuntimeSession) {
        print("extendedRuntimeSessionDidStart")
    }
    
    func extendedRuntimeSessionWillExpire(_ extendedRuntimeSession: WKExtendedRuntimeSession) {
        print("extendedRuntimeSessionWillExpire")
    }
}
