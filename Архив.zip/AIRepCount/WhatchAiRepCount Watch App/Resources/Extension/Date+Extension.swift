//
//  Date+Extension.swift
//  AIRepCount
//
//  Created by Andrey S on 13.02.2024.
//

import Foundation

extension Date {
    func stringFromDateNameFile() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH_mm_ss_SSS"
        return formatter.string(from: self)
    }
    
    func stringFromDateWatch() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss.SSS"
        return formatter.string(from: self)
    }
    
    func stringFromDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        return formatter.string(from: self)
    }
}
