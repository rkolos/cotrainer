//
//  WhatchAiRepCountApp.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 12.02.2024.
//

import SwiftUI

@main
struct WhatchAiRepCount_Watch_AppApp: App {
    @WKApplicationDelegateAdaptor var appDelegate: WatchAppDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
