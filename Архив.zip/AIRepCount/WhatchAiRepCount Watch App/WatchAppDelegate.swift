//
//  WatchAppDelegate.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 07.03.2024.
//

import WatchKit
import HealthKit

class WatchAppDelegate: NSObject, WKApplicationDelegate {
    func handle(_ workoutConfiguration: HKWorkoutConfiguration) {
        let _ = WatchConnectivityManager.shared
    }
}
