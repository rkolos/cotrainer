//
//  SelectedCountView.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 13.02.2024.
//

import SwiftUI

struct SelectedCountView: View {
    @EnvironmentObject private var viewModel: WatchViewModel
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        GeometryReader { proxy in
            ScrollViewReader { proxyReader in
                List(5...30, id: \.self) { value in
                    Button {
                        viewModel.selectedCount = value
                        presentationMode.wrappedValue.dismiss()
                    } label: {
                        Text("\(value)")
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.white)
                    }
                    .frame(maxHeight: .infinity)
                    .background(RoundedRectangle(cornerRadius: 9).fill(viewModel.selectedCount == value ? R.color.blue_medium_c.color : .white.opacity(0.1)))
                    .listRowInsets(EdgeInsets.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                    .listRowPlatterColor(.clear)
                    .id(value)
                }
                .onAppear {
                    proxyReader.scrollTo(viewModel.selectedCount, anchor: .top)
                }
            }
            
        }.navigationTitle(R.string.localizable.w_exercises.localized())
    }
}

#Preview {
    SelectedCountView().environmentObject(WatchViewModel())
}
