//
//  ContentView.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 12.02.2024.
//

import SwiftUI
import HealthKit

struct ContentView: View {
    
    @State var safeAreaInsets: EdgeInsets = .init()
    @State private var showDone = false
    
    @StateObject private var viewModel = WatchViewModel()
    @StateObject private var dbsManager = DBSManager()
    @StateObject private var hapticsEngine = HapticsEngine()

    private let startWorkoutNotifications = NotificationCenter.default.publisher(for: Constants.Notifications.startWorkoutNotifications)
    
    var body: some View {
        
        NavigationView {
            GeometryReader(content: { geometry in
                
                if showDone {
                    R.image.done_ic.image
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .ignoresSafeArea()
                } else {
                    VStack(spacing: 0) {
                        HStack {
                            Button {
                                viewModel.vibrationSelected.toggle()
                                WatchConnectivityManager.shared.send(vibrationMode: viewModel.vibrationSelected)
                            } label: {
                                if viewModel.vibrationSelected {
                                    R.image.vibration_ic.image
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 20, height: 20)
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 2)
                                        .background(Capsule().fill(.white.opacity(0.1)))
                                } else {
                                    R.image.volume_ic.image
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 20, height: 20)
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 2)
                                        .background(Capsule().fill(.white.opacity(0.1)))
                                }
                            }
                            .buttonStyle(.plain)
                            
                            Spacer()
                            
                            Text("60")
                                .font(.system(size: 16, weight: .medium))
                                .lineLimit(1)
                                .background(Capsule()
                                    .fill(.white.opacity(0.1))
                                    .frame(width: 32, height: 24))
                            
                            Spacer()
                            
                            R.image.volume_ic.image
                                .resizable()
                                .frame(width: 19, height: 15)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Capsule()
                                    .fill(.white.opacity(0.1)))
                                .opacity(0.0)
                        }
                        .frame(height: 24)
                        .padding(.horizontal, 10)
                        
                        .padding(.top, safeAreaInsets.top - (WatchSize.current == .mm41 ? 30 : 32))
                        
                        Spacer()
                        
                        Rectangle().fill(.clear).overlay {
                            ZStack {
                                if hapticsEngine.isStart {
                                    Text("\(dbsManager.currentElementCount)")
                                        .font(.system(size: 88, weight: .bold))
                                        .foregroundColor(dbsManager.currentElementCount > 0 ? .white : .white.opacity(0.1))
                                        .minimumScaleFactor(0.5)
                                    
                                    if dbsManager.currentElementCount == 0 {
                                        HStack {
                                            Circle()
                                                .fill(Color(hex: "FF2727"))
                                                .frame(width: 4, height: 4)
                                            
                                            Text(R.string.localizable.w_start_move.localized())
                                                .foregroundColor(.white)
                                                .font(.system(size: 17, weight: .bold))
                                        }
                                    }
                                } else {
                                    NavigationLink(destination: SelectedCountView().environmentObject(viewModel)) {
                                        Text("\(viewModel.selectedCount)")
                                            .font(.system(size: 88, weight: .bold))
                                            .foregroundColor(.white)
                                            .minimumScaleFactor(0.5)
                                            .focusable(!hapticsEngine.isStart)
                                            .digitalCrownRotation(
                                                $viewModel.crownExerciseNumber,
                                                from: 5,
                                                through: 31,
                                                by: 1,
                                                sensitivity: .medium,
                                                isContinuous: true,
                                                isHapticFeedbackEnabled: false
                                            )
                                        
                                    }
                                    .buttonStyle(.plain)
                                    .disabled(hapticsEngine.isStart)
                                }
                            }
                            
                        }
                        
                        Spacer()
                        
                        Button {
                            hapticsEngine.isStart ? hapticsEngine.stop() : hapticsEngine.start()
                        } label: {
                            Text(hapticsEngine.isStart ? R.string.localizable.w_stop.localized() : R.string.localizable.w_start.localized())
                                .font(.system(size: 17, weight: .medium))
                                .foregroundColor(hapticsEngine.isStart ? .black : .white)
                                .frame(maxWidth: .infinity)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(RoundedRectangle(cornerRadius: 9).fill(hapticsEngine.isStart ? R.color.yellow_c.color : R.color.blue_medium_c.color))
                        }.buttonStyle(.plain)
                            .frame(height: 44)
                            .padding(.horizontal, 6)
                            .padding(.bottom, safeAreaInsets.bottom/2 + 10)
                        
                    }
                    .ignoresSafeArea()
                }
            }).background(GeometryReader(content: { geometry in
                Color.clear
            }).getSafeAreaInsets($safeAreaInsets))
            .onChange(of: viewModel.crownExerciseNumber, perform: { newValue in
                viewModel.selectedCount = Int(newValue)
            })
            .onChange(of: dbsManager.currentElementCount, perform: { newValue in
                if newValue >= viewModel.selectedCount, hapticsEngine.isStart {
                    hapticsEngine.stop()
                    
                    showDone = true
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        showDone = false
                    }
                }
                
                viewModel.vibrationMode(count: newValue)
            })
            .onReceive(startWorkoutNotifications) { output in
                if !hapticsEngine.isStart {
                    hapticsEngine.start()
                }
            }
            .onChange(of: hapticsEngine.notificationMessage, perform: { newValue in
                if let model = newValue, hapticsEngine.isStart {
                    
                    DispatchQueue.global(qos: .userInteractive).async {
                        dbsManager.readData(model: model)
                    }
                } else {
                    dbsManager.clean()
                }
            })
        }
        .onAppear {
            let healthKitTypesToWrite: Set<HKSampleType> = [
                HKObjectType.workoutType()]
            
            let healthKitTypesToRead: Set<HKObjectType> = [
                HKObjectType.workoutType()]
            
            hapticsEngine.healthStore.requestAuthorization(toShare: healthKitTypesToWrite, read: healthKitTypesToRead) { success, error in
                
            }
        }
    }
}

#Preview {
    ContentView()
}


