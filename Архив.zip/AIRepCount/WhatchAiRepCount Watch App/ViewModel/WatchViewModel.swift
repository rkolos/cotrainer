//
//  WatchViewModel.swift
//  WhatchAiRepCount Watch App
//
//  Created by Andrey S on 13.02.2024.
//

import SwiftUI

class WatchViewModel: ObservableObject {
    @AppStorage(Constants.AppStorageKey.vibration) var vibrationSelected: Bool = false
    
    @AppStorage(Constants.AppStorageKey.countExercise) var selectedCount: Int = 12 {
        didSet {
            WatchConnectivityManager.shared.send(selectedCount: selectedCount)
        }
    }
    
    @Published var crownExerciseNumber: Double
    
    init() {
        let countPreference = UserDefaults.standard.integer(forKey: Constants.AppStorageKey.countExercise)
        self.selectedCount = countPreference == 0 ? 12 : countPreference
        self.crownExerciseNumber = Double(countPreference == 0 ? 12 : countPreference)
        
        NotificationCenter.default.addObserver(self, selector:#selector(receiveMessage),
                                               name: Constants.Notifications.receiveMessageNotifications,
                                               object: nil)
        
    }
    
    @objc func receiveMessage(_ notification: NSNotification) {
        if let vibrationMode = notification.userInfo?[kVibrationMode] as? Bool {
            vibrationSelected = vibrationMode
        }
        
        if let selectedCount = notification.userInfo?[kSelectedCount] as? Int {
            self.selectedCount = selectedCount
        }
    }
    
    func vibrationMode(count: Int) {
        guard vibrationSelected else { return }
        
        if count == selectedCount {
            WKInterfaceDevice.current().play(.success)
        }
        
        if count == (selectedCount - 3) {
            
            WKInterfaceDevice.current().play(.notification)
        }
        
        if count == (selectedCount - 2) {
            WKInterfaceDevice.current().play(.notification)
        }
        
        if count == (selectedCount - 1) {
            WKInterfaceDevice.current().play(.notification)
        }
    }
    
    
    
    
}
