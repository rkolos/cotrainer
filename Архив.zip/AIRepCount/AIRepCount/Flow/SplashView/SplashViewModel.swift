//
//  SplashViewModel.swift
//  AIRepCount
//
//  Created by Andrey S on 12.02.2024.
//

import SwiftUI

enum FirstScreenType {
    case onboarding
    case dashboard
}

class SplashViewModel: ObservableObject {
    @AppStorage(Constants.AppStorageKey.selectedLanguage) var storageAudioLanguage: LanguageAudio?
    
    @Published var firstScreenType: FirstScreenType?
    
    //MARK: -  Init
    init() {
        NotificationCenter.default.addObserver(self, selector:#selector(detectStart),
                                               name: Constants.Notifications.notAuthUserNotifications,
                                               object: nil)
    }
    
    @objc private func detectStart() {
        if let _ = storageAudioLanguage {
            withAnimation {
                firstScreenType = .dashboard
            }
        } else {
            withAnimation {
                firstScreenType = .onboarding
            }
        }
        
    }
}
