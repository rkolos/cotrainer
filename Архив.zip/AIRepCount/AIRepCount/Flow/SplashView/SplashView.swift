//
//  SplashView.swift
//  AIRepCount
//
//  Created by Andrey S on 12.02.2024.
//

import SwiftUI

struct SplashView: View {
    var body: some View {
        GeometryReader { proxy in
            R.image.launch_ic.image
                .resizable()
                .aspectRatio(contentMode: .fit)
                .padding(.horizontal, 58)
                .ignoresSafeArea()
                .frame(maxHeight: .infinity, alignment: .center)
                .ignoresSafeArea()
                .background(.black)
        }.onAppear(perform: {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                NotificationCenter.default.post(name: Constants.Notifications.notAuthUserNotifications, object: self)
            }
        })
    }
}

#Preview {
    SplashView()
}
