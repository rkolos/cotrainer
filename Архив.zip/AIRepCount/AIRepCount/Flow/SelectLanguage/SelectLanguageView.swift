//
//  SelectLanguageView.swift
//  AIRepCount
//
//  Created by Andrey S on 12.02.2024.
//

import SwiftUI


struct SelectLanguageView: View {
    @AppStorage(Constants.AppStorageKey.selectedLanguage) var storageAudioLanguage: LanguageAudio?
    
    @StateObject private var downloadManager = DownloadManager()
    
    @State private var searchText = ""
    @State private var languages = LanguageAudio.allCases
    
    @State private var selectedLanguage: LanguageAudio?
    
    @State private var openOnboarding = false
    
    var body: some View {
        GeometryReader { geometry in
            NavigationStack {
                VStack(spacing: 0) {
                    ZStack(alignment: .bottom) {
                        ScrollView(showsIndicators: false) {
                            topView
                                .padding(.bottom, isSmall() ? 20 : 40)
                            
                            LanguageSearchView(searchText: $searchText)
                            .padding(.bottom, 16)
                            
                            VStack {
                                ForEach(languages, id: \.self) { id in
                                    LanguageRowView(selectedLanguage: $selectedLanguage, id: id)
                                        .environmentObject(downloadManager)
                                }
                            }
                        }
                        
                        if downloadManager.showWarning {
                            warningView
                        }
                    }.padding(.horizontal, 24)
                    
                    continueButtonView
                    .padding(.horizontal, 24)
                    .padding(.bottom, 16)
                    .padding(.top, 24)
                    
                }
            }
            .background(.black)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .onChange(of: searchText, perform: { value in
            if value.isEmpty {
                languages = LanguageAudio.allCases
            } else {
                languages = LanguageAudio.allCases.filter({$0.title.contains(value)})
            }
        })
        .navigationBarHidden(true)
    }
    
    //MARK: - Child View
    
    private var topView: some View {
        VStack(spacing: 20) {
            Image(systemName: "globe")
                .resizable()
                .frame(width: 40, height: 40)
                .foregroundColor(.white)
                .padding(.top, isSmall() ? 25 : 50)
            
            Text(R.string.localizable.w_selectLangVoice.localized())
                .font(.system(size: isSmall() ? 20 : 28, weight: .semibold))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
            
        }
    }
    
    private var continueButtonView: some View {
        var titleButton: String {
            if let selected = selectedLanguage {
                if let _ = downloadManager.progress {
                    return "\(R.string.localizable.language_downloading.localized())..."
                }
                
                if downloadManager.checkFiles(code: selected) {
                    return R.string.localizable.w_continue.localized()
                } else {
                    return R.string.localizable.language_download_pack.localized()
                }
            } else {
                return R.string.localizable.w_continue.localized()
            }
        }
        
        func isDisabled() -> Bool {
            if let _ = selectedLanguage {
                if let _ = downloadManager.progress {
                    return true
                }
                return false
            } else {
                return true
            }
        }
        
        return Button {
            guard let selectedLanguage = selectedLanguage else { return }
            
            if downloadManager.checkFiles(code: selectedLanguage) {
                storageAudioLanguage = selectedLanguage
                openOnboarding = true
            } else {
                downloadManager.downloadFile(code: selectedLanguage)
            }
        } label: {
            Text(titleButton)
                .foregroundColor(.white)
                .font(.system(size: 17, weight: .medium))
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color(hex: "2E69F2")))
        }.disabled(isDisabled())
            .opacity(isDisabled() ? 0.5 : 1.0)
            .navigationDestination(isPresented: $openOnboarding) {
                HowWorksView()
            }
    }
    
    private var warningView: some View {
        HStack(spacing: 8) {
            Spacer()
            R.image.selected_language_warning_ic.image
            
            Text(R.string.localizable.language_warning_title.localized())
                .multilineTextAlignment(.center)
                .foregroundColor(Color(hex: "FF4F4F"))
                .font(.system(size: 14, weight: .regular))
            Spacer()
        }
        .padding(.all, 8)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color(hex: "FF2727").opacity(0.1)))
        .background(RoundedRectangle(cornerRadius: 8).fill(Color(hex: "0F0F0F")))
        .transition(.move(edge: .bottom).combined(with: .opacity))
        .animation(.easeInOut, value: downloadManager.showWarning)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    downloadManager.showWarning = false
                }
            }
        }
    }
}

#Preview {
    SelectLanguageView()
}
