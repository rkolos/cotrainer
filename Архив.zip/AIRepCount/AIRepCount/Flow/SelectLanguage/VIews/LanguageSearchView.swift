//
//  LanguageSearchView.swift
//  AIRepCount
//
//  Created by Andrey S on 20.02.2024.
//

import SwiftUI

struct LanguageSearchView: View {
    @Binding var searchText: String
    
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: "magnifyingglass")
                .resizable()
                .frame(width: 15, height: 15)
                .foregroundColor(Color(hex: "D9DFE6"))
            
            TextField("", text: $searchText, prompt: Text(R.string.localizable.language_search.localized()).foregroundColor(Color(hex: "F7FAFC")))
                .foregroundColor(Color(hex: "F7FAFC"))
            
        }
        .frame(height: 54)
        .padding(.horizontal, 18)
        .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: "606873"), lineWidth: 1)
        }
    }
}

#Preview {
    LanguageSearchView(searchText: .constant(""))
}
