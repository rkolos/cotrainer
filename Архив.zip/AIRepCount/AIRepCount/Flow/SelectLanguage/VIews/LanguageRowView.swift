//
//  LanguageRowView.swift
//  AIRepCount
//
//  Created by Andrey S on 20.02.2024.
//

import SwiftUI

struct LanguageRowView: View {
    @EnvironmentObject var downloadManager: DownloadManager
    @Binding var selectedLanguage: LanguageAudio?
    @AppStorage(Constants.AppStorageKey.selectedLanguage) var storageAudioLanguage: LanguageAudio?
    
    let id: LanguageAudio
    
    var body: some View {
        Button {
            selectedLanguage = id
        } label: {
            ZStack(alignment: .bottomLeading) {
                HStack {
                    Text("\(id.title)")
                        .foregroundStyle(.white)
                        .font(.system(size: 14, weight: .regular))
                        
                    if downloadManager.checkFiles(code: id) {
                        Text(R.string.localizable.language_downloaded.localized())
                            .foregroundColor(Color(hex: "5286FF"))
                            .font(.system(size: 14, weight: .regular))
                    } else if let progress = downloadManager.progress,
                              downloadManager.startedDownloadedCode == id {
                        Text("\(R.string.localizable.language_downloading.localized()) \(progress)%")
                            .foregroundColor(Color(hex: "5286FF"))
                            .font(.system(size: 14, weight: .regular))
                    }
                    
                    Spacer()
                    
                    R.image.selected_language_ic.image.opacity((storageAudioLanguage == id || selectedLanguage == id) ? 1.0 : 0.0)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 13)
                    .padding(.horizontal, 16)
                    .background(RoundedRectangle(cornerRadius: 14).fill( Color(hex: "FFFFFF").opacity(selectedLanguage == id ? 0.1 : 0.05)))
                
                if let progress = downloadManager.progress,
                   downloadManager.startedDownloadedCode == id {
                    GeometryReader { geo in
                        Rectangle()
                            .fill(Color(hex: "5286FF"))
                            .frame(width: abs(geo.size.width * CGFloat(progress) / 100))
                            .animation(.easeInOut, value: downloadManager.progress)
                    }
                    .frame(height: 4)
                    .background(Rectangle()
                        .fill(Color(hex: "5286FF").opacity(0.2))
                        .frame(maxWidth: .infinity)
                        .frame(height: 4))
                }
            }.clipShape(RoundedRectangle(cornerRadius: 14))
        }.disabled(downloadManager.progress == nil ? false : true)
    }
}

#Preview {
    LanguageRowView(selectedLanguage: .constant(.uk), id: .af)
}
