//
//  HomeView.swift
//  AIRepCount
//
//  Created by Andrey S on 20.02.2024.
//

import SwiftUI
import WatchConnectivity
import Combine

struct HomeView: View {
    @AppStorage(Constants.AppStorageKey.sessionStatus) var sessionStatus: SessionStatus?
    
    var body: some View {
        GeometryReader{ geometry in
            VStack {
                Text(R.string.localizable.home_title.localized())
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 24)
                    .padding(.top, 10)
                
                Spacer()
                
                if sessionStatus == .active {
                    R.image.home_watch_connected_ic.image
                        .padding(.bottom, 24)
                    
                    Text(R.string.localizable.home_run_watch.localized())
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                    
                } else {
                    R.image.home_watch_ic.image
                        .padding(.bottom, 16)
                    
                    Text(R.string.localizable.home_connect_watch.localized())
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                }
                
                Spacer()
                
                if sessionStatus == .active {
                 
                    Text(R.string.localizable.home_unlock_pro.localized())
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(Color(hex: "A4BFFF"))
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 8)
                        .background(RoundedRectangle(cornerRadius: 8).fill(Color(hex: "5286FF").opacity(0.15)))
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                }
            }
            .padding(.bottom, 70)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.black)
        }
        .onAppear(perform: {
            NotificationCenter.default.post(name: Constants.Notifications.unHiddenTabBarNotifications, object: self)
        })
        
    }
}

#Preview {
    HomeView()
}
