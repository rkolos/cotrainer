//
//  TabBarView.swift
//  AIRepCount
//
//  Created by Andrey S on 20.02.2024.
//

import SwiftUI

enum TabBarEnum {
    case home
    case settings
}

struct TabBarView: View {
    @State private var selectedTab: TabBarEnum = .home
    
    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .bottom) {
                Group {
                    if selectedTab == .home {
                        HomeView()
                    } else {
                        SettingsView()
                    }
                }
                
                BottomTabBarView(selectedTab: $selectedTab)
            }
        }
    }
}

struct BottomTabBarView: View {
    
    @Binding var selectedTab: TabBarEnum
    
    private let hiddenTabBarNotifications = NotificationCenter.default.publisher(for: Constants.Notifications.hiddenTabBarNotifications)
    private let unHiddenTabBarNotifications = NotificationCenter.default.publisher(for: Constants.Notifications.unHiddenTabBarNotifications)
    
    @State private var hiddenTabBar = false
    
    var body: some View {
        HStack(spacing: 8) {
            Button {
                withAnimation {
                    selectedTab = .home
                }
            } label: {
                HStack {
                    selectedTab == .home ? R.image.tab_bar_home_select_ic.image : R.image.tab_bar_home_unselect_ic.image
                    
                    if selectedTab == .home {
                        Text(R.string.localizable.tab_bar_home.localized(LocalizeR().localizeLanguage))
                            .foregroundColor(Color(hex: "0F0F0F"))
                            .font(.system(size: 14, weight: .medium))
                    }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color(hex: "1A1A1A").opacity(selectedTab == .home ? 0.1 : 0.0)))
            }

            
            Button {
                withAnimation {
                    selectedTab = .settings
                }
            } label: {
                HStack {
                    selectedTab == .settings ? R.image.tab_bar_settings_select_ic.image : R.image.tab_bar_settings_unselect_ic.image
                    
                    if selectedTab == .settings {
                        Text(R.string.localizable.tab_bar_settings.localized(LocalizeR().localizeLanguage))
                            .foregroundColor(Color(hex: "0F0F0F"))
                            .font(.system(size: 14, weight: .medium))
                    }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color(hex: "1A1A1A").opacity(selectedTab == .settings ? 0.1 : 0.0)))
            }
            
        }.padding(.all, 8)
            .frame(height: 54)
            .background(RoundedRectangle(cornerRadius: 16).fill(.white))
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
            .opacity(hiddenTabBar ? 0.0 : 1.0)
            .onReceive(hiddenTabBarNotifications) { _ in
                hiddenTabBar = true
            }
            .onReceive(unHiddenTabBarNotifications) { _ in
                hiddenTabBar = false
            }
    }
}

#Preview {
    TabBarView()
}
