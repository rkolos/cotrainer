//
//  SettingsVoiceView.swift
//  AIRepCount
//
//  Created by Andrey S on 22.02.2024.
//

import SwiftUI

enum VoiceSettingsType: Int, CaseIterable {
    case full
    case key
    case number
    
    var text: String {
        switch self {
        case .full:
            return R.string.localizable.setting_voice_title_1.localized()
        case .key:
            return R.string.localizable.setting_voice_title_2.localized()
        case .number:
            return R.string.localizable.setting_voice_title_3.localized()
        }
    }
    
    var subTitle: String {
        switch self {
        case .full:
            return R.string.localizable.setting_voice_sub_title_1.localized()
        case .key:
            return R.string.localizable.setting_voice_sub_title_2.localized()
        case .number:
            return R.string.localizable.setting_voice_sub_title_3.localized()
        }
    }
}

struct SettingsVoiceView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @AppStorage(Constants.AppStorageKey.voiceSettingType) var settingSelected: VoiceSettingsType = .full
    
    @AppStorage(Constants.AppStorageKey.vibration) var vibrationSelected: Bool = false
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                topView
                    .padding(.bottom, 24)
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        
                        HStack {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(R.string.localizable.setting_vibration_title.localized())
                                    .foregroundColor(Color(hex: "F7FAFC"))
                                    .font(.system(size: 17, weight: .regular))
                                    .multilineTextAlignment(.leading)
                                
                                Text(R.string.localizable.setting_vibration_sub_title.localized())
                                    .foregroundColor(Color(hex: "808B9A"))
                                    .font(.system(size: 11, weight: .medium))
                                    .multilineTextAlignment(.leading)
                            }
                            
                            
                            Spacer()
                            
                            Toggle("", isOn: $vibrationSelected)
                                .labelsHidden()
                                .padding(.trailing, 2)
                        }
                        
                        ForEach(VoiceSettingsType.allCases, id: \.self) { type in
                            Divider().foregroundColor(.white.opacity(0.1))
                            
                            Button {
                                settingSelected = type
                            } label: {
                                rowVoiceView(type: type)
                            }
                        }
                    }
                }.padding(.top, 16)
                
                Spacer()
            }.padding(.horizontal, 24)
            
            .background(.black)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .navigationBarHidden(true)
        .onChange(of: vibrationSelected) { newValue in
            WatchConnectivityManager.shared.send(vibrationMode: vibrationSelected)
        }
    }
    
    //MARK: - Child View
    
    private var topView: some View {
        HStack(spacing: 20) {
            Button {
                presentationMode.wrappedValue.dismiss()
            } label: {
                Image(systemName: "chevron.left")
                    .frame(width: 24, height: 24)
                    .foregroundColor(.white)
            }
            
            Text(R.string.localizable.settings_language_voice.localized())
                .font(.system(size: 28, weight: .semibold))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    @ViewBuilder func rowVoiceView(type: VoiceSettingsType) -> some View {
        HStack(spacing: 16) {
            Circle()
                .fill(settingSelected == type ? Color(hex: "5286FF") : .clear)
                .frame(width: 9, height: 9)
                .padding(.all, 8)
                .overlay {
                    Circle()
                        .inset(by: 2)
                        .stroke(settingSelected == type ? Color(hex: "5286FF") : .white.opacity(0.4), lineWidth: 2)
                    
                }
            
            VStack(alignment: .leading, spacing: 5) {
                Text(type.text)
                    .foregroundColor(Color(hex: "F7FAFC"))
                    .font(.system(size: 17, weight: .regular))
                    .multilineTextAlignment(.leading)
                
                Text(type.subTitle)
                    .foregroundColor(Color(hex: "808B9A"))
                    .font(.system(size: 11, weight: .medium))
                    .multilineTextAlignment(.leading)
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}

#Preview {
    SettingsVoiceView()
}
