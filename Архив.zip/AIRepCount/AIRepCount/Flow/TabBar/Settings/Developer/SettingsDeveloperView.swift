//
//  SettingsDeveloperView.swift
//  AIRepCount
//
//  Created by Andrey S on 03.03.2024.
//

import SwiftUI

struct SettingsDeveloperView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @State private var showSuccessCopied = false
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                topView
                    .padding(.bottom, 10)
                    .padding(.horizontal, 24)
                
                ZStack(alignment: .bottom) {
                    ScrollView(showsIndicators: true) {
                        VStack(alignment: .leading, spacing: 40) {
                            headerView
                            
                            purposeView
                            
                            howItWorksView
                            
                            implementationView
                            
//                            optionCustomView
//                            
//                            receivingCallbackView
//                            
//                            backwardDeepLinkView
                            
                            benefitsView
                        }.padding(.horizontal, 24)
                    }.padding(.top, 16)
                    
                    if showSuccessCopied {
                        successCopyView
                            .padding(.horizontal, 16)
                    }
                    
                }.padding(.bottom, 16)
            }
            .background(.black)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .navigationBarHidden(true)
    }
    
    //MARK: - Child View
    
    private var topView: some View {
        HStack(spacing: 20) {
            Button {
                presentationMode.wrappedValue.dismiss()
            } label: {
                Image(systemName: "chevron.left")
                    .frame(width: 24, height: 24)
                    .foregroundColor(.white)
            }
            
            Text(R.string.localizable.setting_developer_title.localized())
                .font(.system(size: 28, weight: .semibold))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    private var headerView: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(R.string.localizable.setting_developer_features.localized())
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(Color(hex: "606873"))
            
            Text(R.string.localizable.setting_developer_deep_link.localized())
                .font(.system(size: 28, weight: .semibold))
                .foregroundStyle(.white)
        }
    }
    
    private var purposeView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.setting_developer_purpoce_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Text(R.string.localizable.setting_developer_purpoce_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
        }
    }
    
    private var howItWorksView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.setting_developer_how_work_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Group {
                Text("\(R.string.localizable.setting_developer_how_work_title_1.localized()) ")
                    .font(.system(size: 14, weight: .bold)) +
                Text(" \(R.string.localizable.setting_developer_how_work_sub_title_1.localized())\n\n")
                    .font(.system(size: 14, weight: .regular)) +
                Text("\(R.string.localizable.setting_developer_how_work_title_2.localized()) ").font(.system(size: 14, weight: .bold)) + Text(R.string.localizable.setting_developer_how_work_sub_title_2.localized())
                    .font(.system(size: 14, weight: .regular))
            }
        }
    }
    
    private var implementationView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.setting_developer_implementation_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Text("\(R.string.localizable.setting_developer_implementation_deep_link.localized()) \n")
                .font(.system(size: 14, weight: .bold)) +
            Text(R.string.localizable.setting_developer_implementation_title_1.localized())
                .font(.system(size: 14, weight: .regular))
            
            Text("com.airepcount://5")
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 14, weight: .regular))
                .frame(height: 54)
                .padding(.horizontal, 18)
                .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: "606873"), lineWidth: 1)
                }
            
            Button(action: {
                UIPasteboard.general.string = "com.airepcount://5"
                withAnimation {
                    showSuccessCopied = true
                }
            }, label: {
                HStack(spacing: 6) {
                    R.image.settings_copy_ic.image
                    
                    Text(R.string.localizable.setting_developer_copy_link.localized())
                        .font(.system(size: 17, weight: .medium))
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color(hex: "2E69F2")))
            })
            
            Text(R.string.localizable.setting_developer_implementation_sub_title_1.localized())
                .font(.system(size: 14, weight: .regular))
        }
    }
    
    private var optionCustomView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("\(R.string.localizable.setting_developer_optional_title.localized()) \n")
                .font(.system(size: 14, weight: .bold)) +
            Text(R.string.localizable.setting_developer_optional_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
            
            Text("cotrainer://start?movements=20&appName=yourappa sdfa sdf asdf asf as df saf")
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 14, weight: .regular))
                .frame(height: 54)
                .padding(.horizontal, 18)
                .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: "606873"), lineWidth: 1)
                }
            
            Button(action: {
                UIPasteboard.general.string = "https://goolge.com"
                withAnimation {
                    showSuccessCopied = true
                }
            }, label: {
                HStack {
                    R.image.settings_copy_ic.image
                    
                    Text(R.string.localizable.setting_developer_copy_link.localized())
                        .font(.system(size: 17, weight: .medium))
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color(hex: "2E69F2")))
            })
        }
    }
    
    private var receivingCallbackView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("\(R.string.localizable.setting_developer_receiving_title.localized()) \n")
                .font(.system(size: 14, weight: .bold)) +
            Text(R.string.localizable.setting_developer_receiving_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
            
            Text("cotrainer://start?movements=20&appName=yourappa sdfa sdf asdf asf as df saf")
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 14, weight: .regular))
                .frame(height: 54)
                .padding(.horizontal, 18)
                .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: "606873"), lineWidth: 1)
                }
            
            Button(action: {
                UIPasteboard.general.string = "https://goolge.com"
                withAnimation {
                    showSuccessCopied = true
                }
            }, label: {
                HStack {
                    R.image.settings_copy_ic.image
                    
                    Text(R.string.localizable.setting_developer_copy_link.localized())
                        .font(.system(size: 17, weight: .medium))
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color(hex: "2E69F2")))
            })
            
            Group {
                Text("\(R.string.localizable.setting_developer_receiving_requested_1.localized()) ")
                    .font(.system(size: 14, weight: .bold)) +
                Text("\(R.string.localizable.setting_developer_receiving_requested_2.localized()) ")
                    .font(.system(size: 14, weight: .regular)) +
                Text("\(R.string.localizable.setting_developer_receiving_requested_3.localized()) ")
                    .font(.system(size: 14, weight: .bold)) +
                Text("\(R.string.localizable.setting_developer_receiving_requested_4.localized()) ")
                    .font(.system(size: 14, weight: .regular)) +
                Text("\(R.string.localizable.setting_developer_receiving_requested_5.localized()) ")
                    .font(.system(size: 14, weight: .bold)) +
                Text(R.string.localizable.setting_developer_receiving_requested_6.localized())
                    .font(.system(size: 14, weight: .regular))
            }
        }
    }
    
    private var backwardDeepLinkView: some View {
        VStack(alignment: .leading, spacing: 16) {
            
            Text(R.string.localizable.setting_developer_backward_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Group {
                Text("\(R.string.localizable.setting_developer_backward_title_1.localized()) ")
                     +
                Text("[postback@cotrainer.fit](mailto:postback@cotrainer.fit)") + Text(" \(R.string.localizable.setting_developer_backward_sub_title_1.localized())")
            }.font(.system(size: 14, weight: .regular))
        }
    }
    
    private var benefitsView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.setting_developer_benefits_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Text(R.string.localizable.setting_developer_benefits_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
        }
    }
    
    private var successCopyView: some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 16, height: 16)
                .foregroundColor(Color(hex: "00E676"))
            
            Text(R.string.localizable.setting_developer_link_copied.localized())
                .foregroundColor(.white)
                .font(.system(size: 14, weight: .regular))
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal, 16)
        .frame(height: 50)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(hex: "272728")))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(hex: "00E676"), lineWidth: 1))
        .transition(.move(edge: .bottom).combined(with: .opacity))
        .animation(.easeInOut, value: showSuccessCopied)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    showSuccessCopied = false
                }
            }
        }
    }
}

#Preview {
    SettingsDeveloperView()
}
