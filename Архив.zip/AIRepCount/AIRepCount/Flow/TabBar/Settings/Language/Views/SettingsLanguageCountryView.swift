//
//  SettingsLanguageCountryView.swift
//  AIRepCount
//
//  Created by Andrey S on 21.02.2024.
//

import SwiftUI

struct SettingsLanguageCountryView: View {
    @State private var selectedLanguageCountry: LanguageType?
    
    @Binding var selectedLanguage: LanguageType?
    
    let id: LanguageType
    
    var body: some View {
        Button {
            selectedLanguage = id
        } label: {
            ZStack(alignment: .bottomLeading) {
                HStack {
                    Text("\(id.text)")
                        .foregroundStyle(.white)
                        .font(.system(size: 14, weight: .regular))
                        
                    Spacer()
                    
                    R.image.selected_language_ic.image.opacity((LocalizeR().type == id || selectedLanguage == id) ? 1.0 : 0.0)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 13)
                    .padding(.horizontal, 16)
                    .background(RoundedRectangle(cornerRadius: 14).fill( Color(hex: "FFFFFF").opacity(selectedLanguage == id ? 0.1 : 0.05)))
    
            }.clipShape(RoundedRectangle(cornerRadius: 14))
        }
    }
}

#Preview {
    SettingsLanguageCountryView(selectedLanguage: .constant(.en), id: .en)
}
