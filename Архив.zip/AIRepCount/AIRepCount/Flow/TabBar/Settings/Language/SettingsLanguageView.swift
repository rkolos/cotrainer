//
//  SettingsLanguageView.swift
//  AIRepCount
//
//  Created by Andrey S on 20.02.2024.
//

import SwiftUI

struct SettingsLanguageView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @AppStorage(Constants.AppStorageKey.selectedLanguage) var storageAudioLanguage: LanguageAudio?
    
    @StateObject private var downloadManager = DownloadManager()
    
    @State private var searchText = ""
    @State private var languages = LanguageAudio.allCases
    
    @State private var selectedLanguage: LanguageAudio?
    
    @State private var selectedLanguageScreen = 0
    
    @State private var languagesCountry = LanguageType.allCases
    @State private var selectedLanguageCountry: LanguageType?
    
    init() {
        UISegmentedControl.appearance().selectedSegmentTintColor = UIColor.white.withAlphaComponent(0.1)
    }
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                topView
                    .padding(.bottom, 24)
                
                ZStack(alignment: .bottom) {
                    
                    ScrollView {
                        
                        LanguageSearchView(searchText: $searchText)
                            .padding(.bottom, 16)
                        
                        if selectedLanguageScreen == 0 {
                            VStack {
                                ForEach(languages, id: \.self) { id in
                                    LanguageRowView(selectedLanguage: $selectedLanguage, id: id)
                                        .environmentObject(downloadManager)
                                }
                            }
                        } else {
                            VStack {
                                ForEach(languagesCountry, id: \.self) { id in
                                    SettingsLanguageCountryView(selectedLanguage: $selectedLanguageCountry, id: id)
                                }
                            }
                        }
                    }
                    
                    if downloadManager.showWarning {
                        warningView
                    }
                }.padding(.horizontal, 24)
                
                continueButtonView
                    .padding(.horizontal, 24)
                    .padding(.bottom, 16)
                    .padding(.top, 24)
                
            }
            
            .background(.black)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .onChange(of: selectedLanguageScreen, perform: { newValue in
            searchText = ""
        })
        .onChange(of: searchText, perform: { value in
            if selectedLanguageScreen == 0 {
                if value.isEmpty {
                    languages =  LanguageAudio.allCases
                } else {
                    languages = LanguageAudio.allCases.filter({$0.title.contains(value)})
                }
            } else {
                if value.isEmpty {
                    languagesCountry =  LanguageType.allCases
                } else {
                    languagesCountry = LanguageType.allCases.filter({$0.text.contains(value)})
                }
            }
        })
        .navigationBarHidden(true)
    }
    
    //MARK: - Child View
    
    private var topView: some View {
        VStack(alignment: .leading) {
            HStack(spacing: 20) {
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .frame(width: 24, height: 24)
                        .foregroundColor(.white)
                }
                
                Text(R.string.localizable.settings_language.localized())
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
            }
            
            Picker("", selection: $selectedLanguageScreen) {
                Text(R.string.localizable.settings_language_voice.localized()).tag(0)
                Text(R.string.localizable.settings_language_interface.localized()).tag(1)
            }
            .pickerStyle(.segmented)
        }.padding(.horizontal, 24)
    }
    
    private var continueButtonView: some View {
        var titleButton: String {
            if selectedLanguageScreen == 0 {
                if let selected = selectedLanguage {
                    if let _ = downloadManager.progress {
                        return "\(R.string.localizable.language_downloading.localized())..."
                    }
                    
                    if downloadManager.checkFiles(code: selected) {
                        return R.string.localizable.settings_language_save.localized()
                    } else {
                        return R.string.localizable.language_download_pack.localized()
                    }
                } else {
                    return R.string.localizable.settings_language_save.localized()
                }
            } else {
                return R.string.localizable.settings_language_save.localized()
            }
        }
        
        func isDisabled() -> Bool {
            if selectedLanguageScreen  == 0 {
                if let _ = selectedLanguage {
                    if let _ = downloadManager.progress {
                        return true
                    }
                    return false
                } else {
                    return true
                }
            } else {
                guard let _ = selectedLanguageCountry else { return true }
                
                return false
            }
        }
        
        return Button {
            if selectedLanguageScreen == 0 {
                guard let selectedLanguage = selectedLanguage else { return }
                
                if downloadManager.checkFiles(code: selectedLanguage) {
                    storageAudioLanguage = selectedLanguage
                    presentationMode.wrappedValue.dismiss()
                } else {
                    downloadManager.downloadFile(code: selectedLanguage)
                }
            } else {
                guard let selectedLanguageCountry = selectedLanguageCountry else { return }
                LocalizeR().localizeLanguage = selectedLanguageCountry.rawValue
                presentationMode.wrappedValue.dismiss()
            }
        } label: {
            Text(titleButton)
                .foregroundColor(.white)
                .font(.system(size: 17, weight: .medium))
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color(hex: "2E69F2")))
        }.disabled(isDisabled())
            .opacity(isDisabled() ? 0.5 : 1.0)
    }
    
    private var warningView: some View {
        HStack(spacing: 8) {
            Spacer()
            R.image.selected_language_warning_ic.image
            
            Text(R.string.localizable.language_warning_title.localized())
                .multilineTextAlignment(.center)
                .foregroundColor(Color(hex: "FF4F4F"))
                .font(.system(size: 14, weight: .regular))
            Spacer()
        }
        .padding(.all, 8)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color(hex: "FF2727").opacity(0.1)))
        .background(RoundedRectangle(cornerRadius: 8).fill(Color(hex: "0F0F0F")))
        .transition(.move(edge: .bottom).combined(with: .opacity))
        .animation(.easeInOut, value: downloadManager.showWarning)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    downloadManager.showWarning = false
                }
            }
        }
    }
}

#Preview {
    SettingsLanguageView()
}
