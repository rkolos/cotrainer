//
//  SettingsPartnerView.swift
//  AIRepCount
//
//  Created by Andrey S on 09.03.2024.
//

import SwiftUI

struct SettingsPartnerView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @StateObject private var viewModel = SettingPartnerViewModel()
    
    @FocusState private var isPhoneFocused: Bool
    @FocusState private var isDescriptionFocused: Bool
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                topView
                    .padding(.bottom, 10)
                    .padding(.horizontal, 24)
                
                ZStack(alignment: .bottom) {
                    ScrollView(showsIndicators: true) {
                        VStack(alignment: .leading, spacing: 40) {
                            headerView
                            
                            forefrontView
                            
                            customSolutionView
                            
                            expertiseView
                            
                            collaborateView

                            connectWithUsView
                            
                            formsView
                        }.padding(.horizontal, 24)
                    }.padding(.top, 16)
                    
                    if viewModel.showSuccessSend {
                        successSendView
                            .padding(.horizontal, 16)
                    }
                    
                    if viewModel.showErrorSend {
                        successSendView
                            .padding(.horizontal, 16)
                    }
                    
                }.padding(.bottom, 16)
            }
            .background(.black)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .overlay(overlayView: LoadingIndicatorView(), show: $viewModel.showLoadingIndicator, ignoreSaveArea: false)
        }
        .navigationBarHidden(true)
    }
    
    //MARK: - Child View
    
    private var topView: some View {
        HStack(spacing: 20) {
            Button {
                presentationMode.wrappedValue.dismiss()
            } label: {
                Image(systemName: "chevron.left")
                    .frame(width: 24, height: 24)
                    .foregroundColor(.white)
            }
            
            Text(R.string.localizable.settings_partners_title.localized())
                .font(.system(size: 28, weight: .semibold))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    private var headerView: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(R.string.localizable.settings_partners_sub_title.localized())
                .font(.system(size: 28, weight: .semibold))
                .foregroundStyle(.white)
        }
    }
    
    private var forefrontView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.settings_partners_forefront_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Text(R.string.localizable.settings_partners_forefront_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
        }
    }
    
    private var customSolutionView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.settings_partners_cusom_solution_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Text(R.string.localizable.settings_partners_cusom_solution_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
        }
    }
    
    private var expertiseView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.settings_partners_expertise_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Text(R.string.localizable.settings_partners_expertise_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
        }
    }
    
    private var collaborateView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.settings_partners_colaborate_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Text(R.string.localizable.settings_partners_colaborate_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
        }
    }
    
    private var connectWithUsView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(R.string.localizable.settings_partners_connect_title.localized())
                .font(.system(size: 22, weight: .semibold))
            
            Text(R.string.localizable.settings_partners_connect_sub_title.localized())
                .font(.system(size: 14, weight: .regular))
        }
    }
    
    private var formsView: some View {
        VStack(spacing: 16) {
            TextField("", text: $viewModel.name, prompt: Text(R.string.localizable.settings_partners_name.localized()).foregroundColor(.white))
                .foregroundColor(.white)
                .keyboardType(.namePhonePad)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 14, weight: .regular))
                .frame(height: 54)
                .padding(.horizontal, 18)
                .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: viewModel.isValidName == false ? "FF453A" : "606873"), lineWidth: 1)
                }
            
            TextField("", text: $viewModel.company, prompt: Text(R.string.localizable.settings_partners_company.localized()).foregroundColor(.white))
                .foregroundColor(.white)
                .keyboardType(.namePhonePad)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 14, weight: .regular))
                .frame(height: 54)
                .padding(.horizontal, 18)
                .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: "606873"), lineWidth: 1)
                }
            
            TextField("", text: $viewModel.email, prompt: Text(R.string.localizable.settings_partners_email.localized()).foregroundColor(.white))
                .foregroundColor(.white)
                .keyboardType(.emailAddress)
                .autocorrectionDisabled(true)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 14, weight: .regular))
                .frame(height: 54)
                .padding(.horizontal, 18)
                .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: viewModel.isValidEmail == false ? "FF453A" : "606873"), lineWidth: 1)
                }
            
            TextField("", text: $viewModel.phone, prompt: Text(R.string.localizable.settings_partners_phone.localized()).foregroundColor(.white))
                .foregroundColor(.white)
                .keyboardType(.phonePad)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 14, weight: .regular))
                .frame(height: 54)
                .padding(.horizontal, 18)
                .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                .overlay {
                    RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: viewModel.isValidPhone == false ? "FF453A" : "606873"), lineWidth: 1)
                }
                .focused($isPhoneFocused)
                .toolbar {
                    ToolbarItemGroup(placement: .keyboard) {
                        Spacer()
                        
                        Button(R.string.localizable.settings_done.localized()) {
                            hideKeyboard()
                            isPhoneFocused = false
                        }
                    }
                }
            
            ZStack(alignment: .topLeading) {
                
                if !isDescriptionFocused, viewModel.helpsText.isEmpty {
                    Text(R.string.localizable.settings_placeholder_about.localized())
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.white)
                        .padding()
                }
                
                TextEditor(text: $viewModel.helpsText)
                    .scrollContentBackground(.hidden)
                    .focused($isDescriptionFocused)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(.system(size: 14, weight: .regular))
                    .frame(height: 168)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.1)))
                    .overlay {
                        RoundedRectangle(cornerRadius: 14, style: .continuous).inset(by: 1).stroke(Color(hex: "606873"), lineWidth: 1)
                    }
                
            }
            
            Button(action: {
                hideKeyboard()
                viewModel.submitToGoogleForm()
            }, label: {
                HStack(spacing: 6) {
                    if viewModel.successSend  {
                        Image(systemName: "checkmark")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .foregroundColor(.white)
                            .frame(width: 16, height: 16)
                    } else {
                        Image(systemName: "paperplane")
                            .foregroundColor(.white)
                        
                        Text(R.string.localizable.settings_partners_send.localized())
                            .font(.system(size: 17, weight: .medium))
                            .foregroundColor(.white)
                    }
                }
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color(hex: "2E69F2")))
                .opacity(viewModel.successSend ? 0.5 : 1.0)
            }).disabled(viewModel.successSend)
        }
    }
    
    
    //MARK: - Toast
    private var successSendView: some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 16, height: 16)
                .foregroundColor(Color(hex: "00E676"))
            
            Text(R.string.localizable.settings_partners_message_sent.localized())
                .foregroundColor(.white)
                .font(.system(size: 14, weight: .regular))
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal, 16)
        .frame(height: 50)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(hex: "272728")))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(hex: "00E676"), lineWidth: 1))
        .transition(.move(edge: .bottom).combined(with: .opacity))
        .animation(.easeInOut, value: viewModel.showSuccessSend)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    viewModel.showSuccessSend = false
                }
            }
        }
    }
    
    private var errorSendView: some View {
        HStack(spacing: 8) {
            Image(systemName: "paperplane.fill")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 16, height: 16)
                .foregroundColor(Color(hex: "FF453A"))
            
            Text(viewModel.showErrorMessage)
                .foregroundColor(.white)
                .lineLimit(1)
                .font(.system(size: 14, weight: .regular))
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal, 16)
        .frame(height: 50)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(hex: "272728")))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(hex: "FF453A"), lineWidth: 1))
        .transition(.move(edge: .bottom).combined(with: .opacity))
        .animation(.easeInOut, value: viewModel.showErrorSend)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    viewModel.showErrorSend = false
                }
            }
        }
    }
}

#Preview {
    SettingsPartnerView()
}
