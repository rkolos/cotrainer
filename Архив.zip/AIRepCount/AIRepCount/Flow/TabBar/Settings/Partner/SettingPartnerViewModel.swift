//
//  SettingPartnerViewModel.swift
//  AIRepCount
//
//  Created by Andrey S on 09.03.2024.
//

import SwiftUI
import Combine

class SettingPartnerViewModel: ObservableObject {
    @Published var name = ""
    @Published var isValidName: Bool?
    
    @Published var company = ""
    
    @Published var phone = ""
    @Published var isValidPhone: Bool?
    
    @Published var helpsText = ""
    
    @Published var email = ""
    @Published var isValidEmail: Bool?
    
    @Published var showSuccessSend = false
    @Published var showErrorSend = false
    @Published var showErrorMessage = ""
    
    @Published var successSend = false
    @Published var showLoadingIndicator = false
    
    //MARK: - AnyCancellable
    private var cancellableSet: Set<AnyCancellable> = []
    
    init() {
        $name
            .dropFirst()
        .debounce(for: 0.5, scheduler: RunLoop.main)
        .removeDuplicates()
        .flatMap { name in
            return Just(!name.isEmpty)
                .eraseToAnyPublisher()
        }
        .assign(to: \.isValidName , on: self)
        .store(in: &self.cancellableSet)
        
        $phone
            .dropFirst()
        .debounce(for: 0.5, scheduler: RunLoop.main)
        .removeDuplicates()
        .flatMap { phone in
            return Just(self.isValidPhone(phone))
                .eraseToAnyPublisher()
        }
        .assign(to: \.isValidPhone , on: self)
        .store(in: &self.cancellableSet)
        
        $email
            .dropFirst()
        .debounce(for: 0.5, scheduler: RunLoop.main)
        .removeDuplicates()
        .flatMap { email in
            return Just(self.textFieldValidatorEmail(email))
                .eraseToAnyPublisher()
        }
        .assign(to: \.isValidEmail , on: self)
        .store(in: &self.cancellableSet)
    }
    
    func submitToGoogleForm() {
        guard checkSend() else { return }
        
        let url = URL(string: "https://docs.google.com/forms/u/0/d/e/1FAIpQLSfJ632PXYoZF4q-gh0hhsGepWRgDIpcRACv5kmi7qDvICMGHQ/formResponse")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameters: [String: String] = [
            "entry.1711502364": "\(email) / \(company)",
             "entry.46152069": phone,
              "entry.99173797": name,
            "entry.186075544": helpsText
        ]
        request.httpBody = parameters.map { "\($0)=\($1)" }.joined(separator: "&").data(using: .utf8)
        showLoadingIndicator = true
        let task = URLSession.shared.dataTask(with: request) {  data, response, error in
            DispatchQueue.main.async { [weak self] in
                self?.showLoadingIndicator = false
                guard let data = data, error == nil else {
                    print(error?.localizedDescription ?? "No data")
                    self?.showErrorMessage = error?.localizedDescription ?? "No data"
                    self?.showErrorSend = true
                    return
                }
                
                self?.successSend = true
                self?.showSuccessSend = true
                let _ = String(data: data, encoding: .utf8)
            }
        }
        task.resume()
    }
    
    private func checkSend() -> Bool {
        isValidName = !name.isEmpty
        isValidEmail = textFieldValidatorEmail(email)
        isValidPhone = isValidPhone(phone)
        
        if isValidName == true, isValidEmail == true, isValidPhone == true {
            return true
        } else {
            return false
        }
    }
    
    //----------------------------------------------
    // MARK: - Private func
    //----------------------------------------------
    
    private func isValidPhone(_ phone: String) -> Bool {
        let phoneRegex = "^[0-9+]{0,1}+[0-9]{5,16}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phoneTest.evaluate(with: phone)
    }
    
    private func textFieldValidatorEmail(_ string: String) -> Bool {
        if string.count > 100 {
            return false
        }
        let emailFormat = "(?:[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}" + "~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\" + "x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[\\p{L}0-9](?:[a-" + "z0-9-]*[\\p{L}0-9])?\\.)+[\\p{L}0-9](?:[\\p{L}0-9-]*[\\p{L}0-9])?|\\[(?:(?:25[0-5" + "]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-" + "9][0-9]?|[\\p{L}0-9-]*[\\p{L}0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21" + "-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])"
        //let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: string)
    }
}
