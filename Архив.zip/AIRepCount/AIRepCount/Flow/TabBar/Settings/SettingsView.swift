//
//  SettingsView.swift
//  AIRepCount
//
//  Created by Andrey S on 20.02.2024.
//

import SwiftUI

enum SettingType: Int, CaseIterable {
    case language
    case subscription
    case voice
    case partners
    case dev
    
    var text: String {
        switch self {
        case .language:
            return R.string.localizable.settings_language.localized(LocalizeR().localizeLanguage)
        case .subscription:
            return R.string.localizable.settings_subscription.localized(LocalizeR().localizeLanguage)
        case .voice:
            return R.string.localizable.settings_voice_settings.localized(LocalizeR().localizeLanguage)
        case .partners:
            return R.string.localizable.settings_partners.localized(LocalizeR().localizeLanguage)
        case .dev:
            return R.string.localizable.settings_dev.localized(LocalizeR().localizeLanguage)
        }
    }
    
    var image: Image {
        switch self {
        case .language:
            return R.image.setting_language_ic.image
        case .subscription:
            return R.image.setting_subscription_ic.image
        case .voice:
            return R.image.setting_voice_ic.image
        case .partners:
            return R.image.setting_language_ic.image
        case .dev:
            return R.image.setting_language_ic.image
        }
    }
}

struct SettingsView: View {
    @State private var navigateLanguage = false
    @State private var navigateVoice = false
    @State private var navigateDeveloper = false
    @State private var navigatePartners = false
    
    @AppStorage("localize")
    var localizeLanguage: String? = nil
    
    var body: some View {
        NavigationStack {
            GeometryReader{ geometry in
                VStack(spacing: 0) {
                    Text(R.string.localizable.tab_bar_settings.localized(localizeLanguage))
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 10)
                    
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 16) {
                            ForEach(SettingType.allCases, id: \.self) { type in
                                Button {
                                    NotificationCenter.default.post(name: Constants.Notifications.hiddenTabBarNotifications, object: self)
                                    
                                    switch type {
                                    case .language:
                                        navigateLanguage.toggle()
                                    case .voice:
                                        navigateVoice.toggle()
                                    case .dev:
                                        navigateDeveloper.toggle()
                                    case .partners:
                                        navigatePartners.toggle()
                                    default:
                                        break
                                    }
                                } label: {
                                    HStack(spacing: 0) {
                                        type.image
                                            .opacity((type == .partners || type == .dev) ? 0.0 : 1.0)
                                            .padding(.trailing, 28)
                                        
                                        Text(type.text)
                                            .foregroundColor(.white)
                                            .font(.system(size: 14, weight: .medium))
                                        
                                        Spacer()
                                        
                                        R.image.setting_chevrone_ic.image
                                    }.padding(.all, 20)
                                        .background(RoundedRectangle(cornerRadius: 8).fill(.white.opacity(0.1)))
                                        .overlay(RoundedRectangle(cornerRadius: 8).inset(by: 1).stroke(Color(hex: "606873"), lineWidth: 1))
                                }
                                
                                if type == .voice {
                                    Divider().foregroundColor(.white.opacity(0.1))
                                        .padding(.vertical, 8)
                                }
                            }
                        }.padding(.horizontal, 24)
                            .padding(.top, 25)
                    }
                    
                    Spacer()
                       
                }
                .padding(.bottom, 70)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(.black)
            }
            .onAppear(perform: {
                NotificationCenter.default.post(name: Constants.Notifications.unHiddenTabBarNotifications, object: self)
            })
            .navigationBarHidden(true)
            .navigationDestination(isPresented: $navigateLanguage) {
                SettingsLanguageView()
            }
            .navigationDestination(isPresented: $navigateVoice) {
                SettingsVoiceView()
            }
            .navigationDestination(isPresented: $navigateDeveloper) {
                SettingsDeveloperView()
            }
            .navigationDestination(isPresented: $navigatePartners) {
                SettingsPartnerView()
            }
        }
    }
}

#Preview {
    SettingsView()
}
