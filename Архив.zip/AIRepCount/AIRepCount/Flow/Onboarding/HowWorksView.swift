//
//  HowWorksView.swift
//  AIRepCount
//
//  Created by Andrey S on 20.02.2024.
//

import SwiftUI
import AVKit
import Combine

struct HowWorksView: View {
    @StateObject private var viewModel = HowWokrsViewModel()
    
    @Environment(\.presentationMode) var presentationMode
    @State private var isStarted: Bool = false
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                
                Text(R.string.localizable.onboarding_title.localized())
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.bottom, 8)
                    .padding(.horizontal, 24)
                
                
                Text(R.string.localizable.onboarding_sub_title.localized())
                    .font(.system(size: 14, weight: .regular))
                    .foregroundStyle(Color(hex: "AEB4BF"))
                    .padding(.horizontal, 24)
                
                
                Spacer()
                
                ZStack {
                    R.image.how_it_work_1_ic.image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.bottom, 10)
                        .padding(.horizontal, 24)
                        .padding(.top, isSmall() ? 25 : 50)
                    
                    if let repCount = viewModel.repCount, ["2", "3", "4", "5", "6", "7", "8"].contains(repCount) {
                        Text(viewModel.repCount ?? "")
                            .foregroundColor(.white)
                            .font(.system(size: 64, weight: .bold))
                            .offset(y: 10)
                            .onAppear {
                                self.isStarted = true
                            }
                    }
                    else if (!isStarted) {
                        Text(R.string.localizable.w_start_move.localized())
                            .foregroundColor(.white)
                            .font(.system(size: 12, weight: .bold))
                        
                        
                    } else{
                        Circle()
                            .fill(Color.green)
                            .frame(width: 48, height: 48)
                            .overlay(
                                Image(systemName: "checkmark")
                                    .font(.system(size: 17,weight: .bold))
                                    .foregroundColor(.white)
                            )
                    }
                }
                
                ZStack {
                    R.image.how_it_work_2_ic.image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.horizontal, 24)
                        .opacity(0.0)
                    
                    VideoPlayer(player: viewModel.player)
                        .cornerRadius(10)
                }
                
                Spacer()
                
                Button {
                    NotificationCenter.default.post(name: Constants.Notifications.notAuthUserNotifications, object: self)
                } label: {
                    Text(R.string.localizable.onboarding_lets_try.localized())
                        .foregroundColor(.white)
                        .font(.system(size: 17, weight: .medium))
                        .frame(height: 54)
                        .frame(maxWidth: .infinity)
                        .background(RoundedRectangle(cornerRadius: 14).fill(Color(hex: "2E69F2")))
                }
                .padding(.bottom, 16)
                .padding(.horizontal, 24)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.black)
            
            .navigationBarHidden(false)
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        presentationMode.wrappedValue.dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .foregroundColor(.white)
                            .padding(.bottom, 16)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }.onAppear() {
            viewModel.player.play()
            viewModel.player.rate = 0.5
            viewModel.updateRepCount()
            
        }
        .onDisappear() {
            viewModel.player.pause()
            AudioManager.shared.stopPlayer()
        }
        .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemDidPlayToEndTime)) { _ in
            //viewModel.player.seek(to: .zero)
            
        }
    }
}


#Preview {
    HowWorksView()
}
