//
//  HowWokrsViewModel.swift
//  AIRepCount
//
//  Created by Andrey S on 04.03.2024.
//

import SwiftUI
import AVFoundation

class HowWokrsViewModel: ObservableObject {
    @Published var repCount: String? {
        willSet {
            if newValue?.isEmpty == true, newValue != repCount {
                AudioManager.shared.playRandomDone()
                return
            }
            
            guard newValue != repCount else { return }
            
            switch newValue {
            case "2":
                AudioManager.shared.playFileNameTwoTimes(fileName: .count2)
            case "3":
                AudioManager.shared.playFileNameTwoTimes(fileName: .count3)
            case "4":
                AudioManager.shared.playFileNameTwoTimes(fileName: .count4)
            case "5":
                AudioManager.shared.playFileNameTwoTimes(fileName: .count5)
            case "6":
                AudioManager.shared.playFileNameTwoTimes(fileName: .count6)
            case "7":
                AudioManager.shared.playFileNameTwoTimes(fileName: .count7)
            case "8":
                AudioManager.shared.playFileNameTwoTimes(fileName: .count8)
            default:
                break
            }
        }
    }
    
    @Published var player = AVPlayer(url: URL(fileURLWithPath: Bundle.main.path(forResource: "manfit", ofType: "mov")!))
    
    //MARK: - Private func
    func updateRepCount() {
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] timer in
            guard let `self` = self else { return }
            let currentTime = self.player.currentTime().seconds
            switch currentTime {
            case 2.5...2.9:
                self.repCount = "2"
            case 3.5...3.9:
                self.repCount = "3"
            case 4.5...4.9:
                self.repCount = "4"
            case 5.5...5.9:
                self.repCount = "5"
            case 6.5...6.9:
                self.repCount = "6"
            case 7.5...7.9:
                self.repCount = "7"
            case 8.5...8.9:
                self.repCount = "8"
            case 9...10.9:
                self.repCount = ""
                
            default: break
            }
            if currentTime > 18 { // Прекратить обновление после 18 секунды
                timer.invalidate()
            }
        }
    }
}
