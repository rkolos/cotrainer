//
//  AIRepCountApp.swift
//  AIRepCount
//
//  Created by Andrey S on 06.02.2024.
//

import SwiftUI
import HealthKit

@main
struct AIRepCountApp: App {
    @AppStorage(Constants.AppStorageKey.countExercise) var selectedCount: Int = 12
    @AppStorage(Constants.AppStorageKey.selectedLanguage) var storageAudioLanguage: LanguageAudio?
    
    @StateObject private var splashVM = SplashViewModel()
    @StateObject private var connectivityManager = WatchConnectivityManager.shared
    private var store = HKHealthStore()
    
    var body: some Scene {
        WindowGroup {
            Group {
                switch splashVM.firstScreenType {
                case .onboarding:
                    SelectLanguageView()
                        .transition(AnyTransition.opacity.animation(.easeInOut(duration: 0.2)))
                case .dashboard:
                    TabBarView()
                        .transition(AnyTransition.opacity.animation(.easeInOut(duration: 0.2)))
                default:
                    SplashView()
                        .transition(AnyTransition.opacity.animation(.easeInOut(duration: 0.2)))
                }
            }
            .onOpenURL { url in
                print(url)
                
                guard let host = url.host, let number = Int(host), let _ = storageAudioLanguage else { return }
                
                let configuration = HKWorkoutConfiguration()
                configuration.activityType = .traditionalStrengthTraining
                configuration.locationType = .unknown

                store.startWatchApp(with: configuration) { result, error in
                    if let error = error {
                        print("*** An error occurred while starting a workout on Apple Watch: \(error.localizedDescription) ***")
                    } else {
                        selectedCount = number
                        print("*** Workout Session Started ***")
                        
                        if let query = url.query?.components(separatedBy: "="), query.count == 2  {
                            PreferencesManager.sharedManager.deepLinkValue = query[1]
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            WatchConnectivityManager.shared.send(selectedCount: number, startWorkout: true)
                        }
                    }
                }
            }
        }
    }
}
