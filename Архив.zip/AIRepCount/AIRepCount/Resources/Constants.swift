//
//  Constants.swift
//  AIRepCount
//
//  Created by Andrey S on 12.02.2024.
//

import Foundation

struct Constants {
    struct AppStorageKey {
        //Public
        static let selectedLanguage = "selectedLanguage"
        static let countExercise = "countExercise"
        
        //Private
        static let sessionStatus = "sessionStatus"
        static let voiceSettingType = "voiceSettingType"
        static let vibration = "vibration"
    }
    
    struct Notifications {
        static let notAuthUserNotifications: NSNotification.Name = NSNotification.Name("notAuthUserNotifications")
        
        static let hiddenTabBarNotifications: NSNotification.Name = NSNotification.Name("hiddenTabBarNotifications")
        static let unHiddenTabBarNotifications: NSNotification.Name = NSNotification.Name("unHiddenTabBarNotifications")
    }
}
