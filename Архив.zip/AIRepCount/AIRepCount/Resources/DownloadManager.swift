//
//  DownloadFileManager.swift
//  AIRepCount
//
//  Created by Andrey S on 19.02.2024.
//

import AVFoundation
import Combine
import SwiftUI

final class DownloadManager: ObservableObject {
    struct StatusDownloadModel {
        let url: URL
        var progress: Double
    }
    
    @Published var isDownloading = false
    @Published var isDownloaded = false
    @Published var progress: Int?
    @Published var startedDownloadedCode: LanguageAudio?
    @Published var showWarning = false
    
    @Published private var downloaded: [StatusDownloadModel] = []
    private var cancellable = Set<AnyCancellable>()
    
    var observations: [NSKeyValueObservation] = []
    
    func downloadFile(code: LanguageAudio) {
        progress = nil
        startedDownloadedCode = code
        observations.removeAll()
        cancellable.removeAll()
        
        isDownloading = true

        let docsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first

        let dirPath = docsUrl?.appendingPathComponent(code.rawValue)
        do
        {
            try FileManager.default.createDirectory(atPath: dirPath!.path, withIntermediateDirectories: true, attributes: nil)
        }
        catch let error as NSError
        {
            print("Unable to create directory \(error.debugDescription)")
        }
            
        $downloaded.sink { model in
            let progress = (model.compactMap({$0.progress}).reduce(0, +) / Double(model.count)) * 100
            guard progress.isFinite else { return }
            self.progress = Int(progress)
            
            if progress >= 100 {
                self.progress = nil
            }
        }
        .store(in: &cancellable)
        
        downloaded = code.files.compactMap({StatusDownloadModel(url: $0, progress: 0.0)})
        progress = 0
        
        for url in code.files {
            let destinationUrl = docsUrl?.appendingPathComponent("\(code.rawValue)/\(url.lastPathComponent)")
            if let destinationUrl = destinationUrl {
                if (FileManager().fileExists(atPath: destinationUrl.path)) {
                    print("File already exists")
                    if let index = downloaded.firstIndex(where: {$0.url == url}) {
                        downloaded[index].progress = 1.0
                    }
                    
                    isDownloading = false
                } else {
                    let urlRequest = URLRequest(url: url)
                    
                    let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
                        DispatchQueue.main.async {
                            if let error = error {
                                withAnimation {
                                    self.showWarning = true
                                }
                                
                                print("Request error: \(error)")
                                self.isDownloading = false
                                return
                            }
                            
                            guard let response = response as? HTTPURLResponse else { return }
                            
                            if response.statusCode == 200 {
                                guard let data = data else {
                                    self.isDownloading = false
                                    return
                                }
                                
                                do {
                                    try data.write(to: destinationUrl, options: Data.WritingOptions.atomic)
                                    
                                    if let index = self.downloaded.firstIndex(where: {$0.url == url}) {
                                        self.downloaded[index].progress = 1.0
                                    }
                                    
                                    print("Downloaded: \(destinationUrl)")
                                    DispatchQueue.main.async {
                                        self.isDownloading = false
                                        self.isDownloaded = true
                                    }
                                } catch let error {
                                    withAnimation {
                                        self.showWarning = true
                                    }
                                    print("Error decoding: \(error)")
                                    self.isDownloading = false
                                }
                                
                            } else {
                                withAnimation {
                                    self.showWarning = true
                                }
                                print(response)
                            }
                        }
                    }
                    
                    let observation = dataTask.progress.observe(\.fractionCompleted) { [weak self] (progress, _) in
                        DispatchQueue.main.async {
                            guard let self = self else { return }
                            if let index = self.downloaded.firstIndex(where: {$0.url == url}) {
                                self.downloaded[index].progress = progress.fractionCompleted
                            }
                        }
                    }
                    
                    observations.append(observation)
                    
                    dataTask.resume()
                }
            }
        }
    }

    func deleteFile() {
        let docsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first

        let destinationUrl = docsUrl?.appendingPathComponent("myVideo.mp4")
        if let destinationUrl = destinationUrl {
            guard FileManager().fileExists(atPath: destinationUrl.path) else { return }
            do {
                try FileManager().removeItem(atPath: destinationUrl.path)
                print("File deleted successfully")
                isDownloaded = false
            } catch let error {
                print("Error while deleting video file: \(error)")
            }
        }
    }

    func checkFileExists(url: URL) {
        let docsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first

        let destinationUrl = docsUrl?.appendingPathComponent("workout/\(url.lastPathComponent)")
        if let destinationUrl = destinationUrl {
            if (FileManager().fileExists(atPath: destinationUrl.path)) {
                isDownloaded = true
            } else {
                isDownloaded = false
            }
        } else {
            isDownloaded = false
        }
    }

    func checkFiles(code: LanguageAudio) -> Bool {
        let docsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first

        let dirPath = docsUrl?.appendingPathComponent(code.rawValue)
        do
        {
            try FileManager.default.createDirectory(atPath: dirPath!.path, withIntermediateDirectories: true, attributes: nil)
        }
        catch let error as NSError
        {
            print("Unable to create directory \(error.debugDescription)")
            return false
        }
        
        for url in code.files {
            let destinationUrl = docsUrl?.appendingPathComponent("\(code.rawValue)/\(url.lastPathComponent)")
            if !FileManager.default.fileExists(atPath: destinationUrl!.path) {
                return false
            }
        }
        
        return true
    }
}
