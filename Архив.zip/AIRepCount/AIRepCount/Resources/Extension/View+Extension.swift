//
//  View+Extension.swift
//  AIRepCount
//
//  Created by Andrey S on 12.02.2024.
//

import SwiftUI

extension View {
    func safeAreaBottom() -> CGFloat? {
        return UIApplication.shared.connectedScenes.flatMap { ($0 as? UIWindowScene)?.windows ?? [] }.first { $0.isKeyWindow }?.safeAreaInsets.bottom
    }
    
    func safeAreaTop() -> CGFloat {
        return UIApplication.shared.connectedScenes.flatMap { ($0 as? UIWindowScene)?.windows ?? [] }.first { $0.isKeyWindow }?.safeAreaInsets.top ?? 0
    }
    
    func frame() -> CGRect? {
        return UIApplication.shared.connectedScenes.flatMap { ($0 as? UIWindowScene)?.windows ?? [] }.first { $0.isKeyWindow }?.frame
    }
    
    func isSmall() -> Bool {
        let isSmallScreen = UIScreen.main.bounds.size.height < 750
        return isSmallScreen
    }
    
    func isBig() -> Bool {
        let isSmallScreen = UIScreen.main.bounds.size.height > 900
        return isSmallScreen
    }
    
    func hideKeyboard() {
        let resign = #selector(UIResponder.resignFirstResponder)
        UIApplication.shared.sendAction(resign, to: nil, from: nil, for: nil)
    }
    
}
