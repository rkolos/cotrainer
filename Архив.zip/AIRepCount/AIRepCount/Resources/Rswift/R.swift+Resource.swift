//
//  R.swift+Resource.swift
//  AIRepCount
//
//  Created by Andrey S on 12.02.2024.
//

import SwiftUI
import RswiftResources

// MARK: - ImageResource
extension RswiftResources.ImageResource {
    var image: Image {
        Image(name)
    }
}

// MARK: - ColorResource
extension RswiftResources.ColorResource {
    var color: Color {
        Color(name)
    }
    
    var uiColor: UIColor {
        UIColor(named: name)!
    }
}

enum LanguageType: String, CaseIterable, Codable {
    case en
    case uk
    case ar
    case bg
    case ca
    case zh
    case zhHans = "zh-Hans"
    case zhHant = "zh-Hant"
    case hr
    case cs
    case da
    case nl
    case fi
    case fr
    case frCA = "fr-CA"
    case de
    case el
    case he
    case hi
    case hu
    case id
    case it
    case ja
    case ko
    case ms
    case nb
    case pl
    case pt
    case ptBR = "pt-BR"
    case ro
    case sk
    case es
    case sv
    case th
    case tr
    case vi
                                                                                                                                                
    var text: String {
        switch self {
        case .en:
            return "English (U.S.)"
        case .uk:
            return "Ukranian"
        case .ar:
            return "Arabic"
        case .bg:
            return "Bulgarian"
        case .ca:
            return "Catalan"
        case .zh:
            return "Chinese"
        case .zhHans:
            return "Chinese (Simplified)"
        case .zhHant:
            return "Chinese (Traditional)"
        case .hr:
            return "Croatian"
        case .cs:
            return "Czech"
        case .da:
            return "Danish"
        case .nl:
            return "Dutch"
        case .fi:
            return "Finnish"
        case .fr:
            return "French"
        case .frCA:
            return "French (Canadian)"
        case .de:
            return "German"
        case .el:
            return "Greek"
        case .he:
            return "Hebrew"
        case .hi:
            return "Hindi"
        case .hu:
            return "Hungarian"
        case .id:
            return "Indonesian"
        case .it:
            return "Italian"
        case .ja:
            return "Japanese"
        case .ko:
            return "Korean"
        case .ms:
            return "Malay"
        case .nb:
            return "Norwegian (Bokmal)"
        case .pl:
            return "Polish"
        case .pt:
            return "Portuguese"
        case .ptBR:
            return "Portuguese (Brazil)"
        case .ro:
            return "Romanian"
        case .sk:
            return "Slovak"
        case .es:
            return "Spanish"
        case .sv:
            return "Swedish"
        case .th:
            return "Thai"
        case .tr:
            return "Turkish"
        case .vi:
            return "Vietnamese"
        }
    }
}

extension StringResource {
    public func localized(_ language: String? = nil) -> String {
        
        let currentLanguage = language ?? LocalizeR().localizeLanguage ?? Locale.current.language.languageCode?.identifier ?? "en"
      
        let baseBundle = Bundle.main
        let fallback = baseBundle.localizedString(forKey: "\(key)", value: "\(key)", table: tableName)
        
        guard
            let localizedPath = source.bundle?.path(forResource: currentLanguage, ofType: "lproj"),
            let localizedBundle = Bundle(path: localizedPath)
        else {
            return fallback
        }
        
        return localizedBundle.localizedString(forKey: "\(key)", value: fallback, table: tableName)
    }
}

final class LocalizeR {
    @AppStorage("localize")
    var localizeLanguage: String? = nil {
        didSet {
#if os(iOS)
            WatchConnectivityManager.shared.send(interfaceLanguage: localizeLanguage)
#endif
        }
    }
    
    var type: LanguageType {
        
        let code = LocalizeR().localizeLanguage ?? Locale.current.language.languageCode?.identifier ?? "en"
        
        return LanguageType(rawValue: code) ?? .en
    }
}
