//
//  LoadingIndicator.swift
//  AIRepCount
//
//  Created by Andrey S on 09.03.2024.
//

import SwiftUI

struct LoadingIndicatorView: View {
    
    //MARK: - @Binding
    private let text: String?
    
    //MARK: - Initializer
    init(text: String? = nil) {
        self.text = text
    }
    
    //MARK: - Initializer
    var body: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                
                VStack(spacing: 10) {
                    if let text = text {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: Color.white))
                            .padding(.top, 27)
                            .padding(.bottom, 10)
                        
                            Text(text)
                                .foregroundColor(Color.white)
                                .font(.system(size: 13, weight: .semibold))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 12)
                                .padding(.bottom, 27)
                    } else {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: Color.white))
                            .padding(.top, 27)
                            .padding(.horizontal, 27)
                            .padding(.bottom, 27)
                    }
                }
                .background(RoundedRectangle(cornerRadius: 16).fill(Color.black.opacity(0.75)))
                .transition(.scale)
                
                Spacer()
            }
            Spacer()
        }
        .onAppear {
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
        .onDisappear {
            UIApplication.shared.endIgnoringInteractionEvents()
        }
    }
    
}
