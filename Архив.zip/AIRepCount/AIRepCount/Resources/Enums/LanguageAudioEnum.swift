//
//  LanguageAudioEnum.swift
//  AIRepCount
//
//  Created by Andrey S on 19.02.2024.
//

import Foundation

enum LanguageAudio: String, CaseIterable {
    case af
    case sq
    case am
    case ar
    case hy
    case az
    case eu
    case bn
    case bs
    case bg
    case my
    case ca
    case zh
    case hr
    case cs
    case da
    case nl
    case en
    case et
    case fil
    case fi
    case fr
    case gl
    case ka
    case de
    case el
    case gu
    case he
    case hu
    case iss = "is"
    case id
    case ga
    case it
    case ja
    case jv
    case kn
    case kk
    case km
    case ko
    case lo
    case lv
    case lt
    case mk
    case ms
    case ml
    case mt
    case mr
    case mn
    case ne
    case no
    case ps
    case fa
    case pl
    case pt
    case ro
    case sr
    case si
    case sk
    case sl
    case so
    case es
    case su
    case sw
    case sv
    case ta
    case te
    case th
    case tr
    case uk
    case ur
    case uz
    case vi
    case cy
    case zu

    var files: [URL] {
        return FileNameAudioEnum.allCases.compactMap({URL(string:  "https://cotrainer.sfo2.cdn.digitaloceanspaces.com/lang/\(self.rawValue)/\(self.rawValue)-\($0.rawValue).mp3")})
    }
    
    var title: String {
        switch self {
        case .af:
            return "Afrikaans (\(self.rawValue.uppercased()))"
        case .sq:
            return "Albanian (\(self.rawValue.uppercased()))"
        case .am:
            return "Amharic (\(self.rawValue.uppercased()))"
        case .ar:
            return "Arabic (\(self.rawValue.uppercased()))"
        case .hy:
            return "Armenian (\(self.rawValue.uppercased()))"
        case .az:
            return "Azerbaijani (\(self.rawValue.uppercased()))"
        case .eu:
            return "Basque (\(self.rawValue.uppercased()))"
        case .bn:
            return "Bengali (\(self.rawValue.uppercased()))"
        case .bs:
            return "Bosnian (\(self.rawValue.uppercased()))"
        case .bg:
            return "Bulgarian (\(self.rawValue.uppercased()))"
        case .my:
            return "Burmese (\(self.rawValue.uppercased()))"
        case .ca:
            return "Catalan (\(self.rawValue.uppercased()))"
        case .zh:
            return "Chinese (\(self.rawValue.uppercased()))"
        case .hr:
            return "Croatian (\(self.rawValue.uppercased()))"
        case .cs:
            return "Czech (\(self.rawValue.uppercased()))"
        case .da:
            return "Danish (\(self.rawValue.uppercased()))"
        case .nl:
            return "Dutch (\(self.rawValue.uppercased()))"
        case .en:
            return "English (\(self.rawValue.uppercased()))"
        case .et:
            return "Estonian (\(self.rawValue.uppercased()))"
        case .fil:
            return "Filipino (\(self.rawValue.uppercased()))"
        case .fi:
            return "Finnish (\(self.rawValue.uppercased()))"
        case .fr:
            return "French (\(self.rawValue.uppercased()))"
        case .gl:
            return "Galicia (\(self.rawValue.uppercased()))"
        case .ka:
            return "Georgian (\(self.rawValue.uppercased()))"
        case .de:
            return "German (\(self.rawValue.uppercased()))"
        case .el:
            return "Greek (\(self.rawValue.uppercased()))"
        case .gu:
            return "Gujarati (\(self.rawValue.uppercased()))"
        case .he:
            return "Hebrew (\(self.rawValue.uppercased()))"
        case .hu:
            return "Hungarian (\(self.rawValue.uppercased()))"
        case .iss:
            return "Icelandic (\(self.rawValue.uppercased()))"
        case .id:
            return "Indonesian (\(self.rawValue.uppercased()))"
        case .ga:
            return "Irish (\(self.rawValue.uppercased()))"
        case .it:
            return "Italian (\(self.rawValue.uppercased()))"
        case .ja:
            return "Japanese (\(self.rawValue.uppercased()))"
        case .jv:
            return "Javanese (\(self.rawValue.uppercased()))"
        case .kn:
            return "Kannada (\(self.rawValue.uppercased()))"
        case .kk:
            return "Kazakh (\(self.rawValue.uppercased()))"
        case .km:
            return "Khmer (\(self.rawValue.uppercased()))"
        case .ko:
            return "Korean (\(self.rawValue.uppercased()))"
        case .lo:
            return "Lao (\(self.rawValue.uppercased()))"
        case .lv:
            return "Latvian (\(self.rawValue.uppercased()))"
        case .lt:
            return "Lithuanian (\(self.rawValue.uppercased()))"
        case .mk:
            return "Macedonian (\(self.rawValue.uppercased()))"
        case .ms:
            return "Malay (\(self.rawValue.uppercased()))"
        case .ml:
            return "Malayalam (\(self.rawValue.uppercased()))"
        case .mt:
            return "Maltese (\(self.rawValue.uppercased()))"
        case .mr:
            return "Marathi (\(self.rawValue.uppercased()))"
        case .mn:
            return "Mongolian (\(self.rawValue.uppercased()))"
        case .ne:
            return "Nepali (\(self.rawValue.uppercased()))"
        case .no:
            return "Norwegian (\(self.rawValue.uppercased()))"
        case .ps:
            return "Pashto (\(self.rawValue.uppercased()))"
        case .fa:
            return "Persian (\(self.rawValue.uppercased()))"
        case .pl:
            return "Polish (\(self.rawValue.uppercased()))"
        case .pt:
            return "Portuguese (\(self.rawValue.uppercased()))"
        case .ro:
            return "Romanian (\(self.rawValue.uppercased()))"
        case .sr:
            return "Serbian (\(self.rawValue.uppercased()))"
        case .si:
            return "Sinhala (\(self.rawValue.uppercased()))"
        case .sk:
            return "Slovak (\(self.rawValue.uppercased()))"
        case .sl:
            return "Slovenian (\(self.rawValue.uppercased()))"
        case .so:
            return "Somali (\(self.rawValue.uppercased()))"
        case .es:
            return "Spanish (\(self.rawValue.uppercased()))"
        case .su:
            return "Sundanese (\(self.rawValue.uppercased()))"
        case .sw:
            return "Swahili (\(self.rawValue.uppercased()))"
        case .sv:
            return "Swedish (\(self.rawValue.uppercased()))"
        case .ta:
            return "Tamil (\(self.rawValue.uppercased()))"
        case .te:
            return "Telugu (\(self.rawValue.uppercased()))"
        case .th:
            return "Thai (\(self.rawValue.uppercased()))"
        case .tr:
            return "Turkish (\(self.rawValue.uppercased()))"
        case .uk:
            return "Ukrainian (\(self.rawValue.uppercased()))"
        case .ur:
            return "Urdu (\(self.rawValue.uppercased()))"
        case .uz:
            return "Uzbek (\(self.rawValue.uppercased()))"
        case .vi:
            return "Vietnamese (\(self.rawValue.uppercased()))"
        case .cy:
            return "Welsh (\(self.rawValue.uppercased()))"
        case .zu:
            return "Zulu (\(self.rawValue.uppercased()))"
        }
    }
}
