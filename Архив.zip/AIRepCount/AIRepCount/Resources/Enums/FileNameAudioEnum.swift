//
//  FileNameAudioEnum.swift
//  AIRepCount
//
//  Created by Andrey S on 19.02.2024.
//

import Foundation

enum FileNameAudioEnum: String, CaseIterable {
    case progress1 = "progress-1"
    case progress2 = "progress-2"
    case progress3 = "progress-3"
    case progress50 = "progress-50"
    case done15 = "done-15"
    case done14 = "done-14"
    case done13 = "done-13"
    case done12 = "done-12"
    case done11 = "done-11"
    case done10 = "done-10"
    case done9 = "done-9"
    case done8 = "done-8"
    case done7 = "done-7"
    case done6 = "done-6"
    case done5 = "done-5"
    case done4 = "done-4"
    case done3 = "done-3"
    case done2 = "done-2"
    case done1 = "done-1"
    case count30 = "30"
    case count29 = "29"
    case count28 = "28"
    case count27 = "27"
    case count26 = "26"
    case count25 = "25"
    case count24 = "24"
    case count23 = "23"
    case count22 = "22"
    case count21 = "21"
    case count20 = "20"
    case count19 = "19"
    case count18 = "18"
    case count17 = "17"
    case count16 = "16"
    case count15 = "15"
    case count14 = "14"
    case count13 = "13"
    case count12 = "12"
    case count11 = "11"
    case count10 = "10"
    case count9 = "9"
    case count8 = "8"
    case count7 = "7"
    case count6 = "6"
    case count5 = "5"
    case count4 = "4"
    case count3 = "3"
    case count2 = "2"
}
