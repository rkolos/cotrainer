//
//  OverlayModifier.swift
//  AIRepCount
//
//  Created by Andrey S on 09.03.2024.
//

import SwiftUI

struct Overlay<T: View>: ViewModifier {

    @Binding var show: Bool
    let overlayView: T
    let ignoreSaveArea: Bool

    func body(content: Content) -> some View {
        ZStack {
            content
            if show {
                if ignoreSaveArea {
                    overlayView.ignoresSafeArea(.all)
                } else {
                    overlayView
                }
            }
        }
    }
}

extension View {
    func overlay<T: View>( overlayView: T, show: Binding<Bool>, ignoreSaveArea: Bool) -> some View {
        self.modifier(Overlay.init(show: show, overlayView: overlayView, ignoreSaveArea: ignoreSaveArea))
    }
}

